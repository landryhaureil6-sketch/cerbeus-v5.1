# Over 5.1.death — Silly Development

## Déploiement
1. Envoie le contenu de ce ZIP dans le gestionnaire de fichiers Silly Dev.
2. Ne téléverse pas `node_modules`.
3. Start Command : `npm start`.
4. Ouvre la console Live.

Le projet possède `package.json` et `index.js` à la racine, comme attendu par Silly Dev. Les dépendances sont installées automatiquement au déploiement.

## Première connexion WhatsApp
Le bot utilise le code de jumelage et **ne demande aucun numéro au démarrage**. Le compte de connexion est fixé dans le code à celui du propriétaire.

Dans WhatsApp : **Appareils connectés → Connecter un appareil → Connecter avec un numéro de téléphone**, puis saisis le code affiché par le serveur.

Une fois associé, ne supprime jamais `data/sessions/main` : les identifiants y sont conservés afin que le bot puisse se reconnecter après un redémarrage.

## Préfixe
Le préfixe est `!`.

Exemple : `!ping`

## Ressources
Silly Dev indique pour ses serveurs gratuits 25 % d'un cœur CPU, 256 MB de RAM et 512 MB de disque. Le projet doit donc rester léger et éviter de charger de gros médias entièrement en mémoire.
