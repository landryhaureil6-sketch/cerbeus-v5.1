# APIs

Les clés externes ne sont jamais embarquées en clair dans le ZIP.

Variables facultatives :
- `HUGGINGFACE_API_KEY` : clé Hugging Face Router API.
- `HUGGINGFACE_MODEL` : modèle utilisé par `!ai` (défaut: HuggingFaceH4/zephyr-7b-beta).

`!ai <question>` utilise l'API seulement si `HUGGINGFACE_API_KEY` est définie.
La traduction et la recherche GitHub utilisent déjà des endpoints publics sans clé.
- `GROQ_API_KEY` : clé Groq optionnelle. Si présente, `!ai`, `!gpt` et `!ask` utilisent Groq en priorité.
