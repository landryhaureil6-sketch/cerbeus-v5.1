# Over v5.1.death — Silly Development (Free)

Cette édition est prévue pour Silly Development : Node.js, processus longue durée, sans tmux.

## Configuration dans le panneau Silly Dev

Ajoute les variables d'environnement suivantes :

- `PAIRING_NUMBER` = même numéro
- `PAIRING_ENABLED` = `true`
- `PAIRING_CODE` = laisser vide pour que WhatsApp génère le code, ou mettre un code alphanumérique de 8 caractères si la version de Baileys/WhatsApp l'accepte
- `BOT_MODE` = `private`
- `BOT_PREFIX` = `?`
- Utilisateur principal #2 = `696789087`
- `LOG_LEVEL` = `info`

Ne mets jamais une session WhatsApp dans le dépôt public.

## Commande de démarrage

`npm start`

Le panneau doit utiliser `npm start` comme Start Command. Le programme n'utilise pas tmux et n'essaie pas de lancer Termux.

## Première connexion

1. Déploie le projet.
2. Ouvre la console Live.
3. Le programme affiche un code de jumelage WhatsApp de 8 caractères. La fenêtre initiale de jumelage est de 1 min 30 s. Le QR code est désactivé.
4. Dans WhatsApp : Appareils connectés → Connecter un appareil → Connecter avec un numéro de téléphone.
5. Saisis le code affiché.
6. La session est sauvegardée dans `data/sessions/main`.

Si la plateforme recrée le disque du serveur, la session peut être perdue : conserve donc le stockage persistant fourni par la plateforme et ne supprime pas `data/sessions/main`.

## Anti-spam

La règle incluse est : 5 messages maximum dans la fenêtre configurée ; le 6e déclenche la sanction si l'auteur n'est ni propriétaire ni administrateur. La fenêtre par défaut est de 500 ms.


### Connexion
Le bot utilise le code de jumelage WhatsApp. Lancez `npm start`, ouvrez les logs et dans WhatsApp : Appareils connectés → Connecter avec un numéro de téléphone, puis saisissez le code affiché.


### Réaction automatique
- `!autoreact on` : active la réaction automatique.
- `!autoreact off` : désactive la réaction automatique.
- `!autoreact set ❤️` : choisit l'emoji.
- `!autoreact status` : affiche l'état.

Les commandes de téléchargement direct (`!son`, `!video`, `!film`, `!download`) attendent une URL publique directe et ne contournent pas les protections des plateformes.
