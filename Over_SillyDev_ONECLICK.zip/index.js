// Silly Development entry point for Over 5.1.death
require('./src/index.js');
