# Over — Silly Dev : fonctionnement longue durée

- La session WhatsApp est stockée dans `data/sessions/main`.
- Ne supprimez jamais ce dossier après un jumelage réussi.
- Les dépendances sont installées par Silly Dev depuis `package.json`.
- Le bot utilise une reconnexion progressive et une surveillance de la socket.
- Une exception JavaScript fatale fait terminer proprement le processus afin que Silly Dev puisse le redémarrer automatiquement.
- Aucun système de ping HTTP ou de faux keep-alive n'est utilisé.

## Limite importante

Aucun code ne peut garantir un mois de connexion si WhatsApp révoque/déconnecte le compte, si le serveur est suspendu, ou si une maintenance/outage survient. L'objectif de cette version est de rester connecté automatiquement aussi longtemps que la session WhatsApp et l'hébergement restent valides.

## Connexion longue durée
- Les credentials WhatsApp sont conservés dans `data/sessions/main`.
- `creds.update` est sauvegardé en continu.
- Les coupures réseau temporaires sont reconnectées automatiquement.
- Un redémarrage du serveur ne doit pas demander un nouveau code si les credentials WhatsApp sont encore valides.
- En cas de vraie révocation WhatsApp (401) ou session invalide (500), aucun nouveau code n'est généré en boucle : un nouveau jumelage manuel est nécessaire.
- Objectif : fonctionnement continu d'une semaine ou plus, sous réserve de la disponibilité de Silly Dev et de la validité de la session WhatsApp.
