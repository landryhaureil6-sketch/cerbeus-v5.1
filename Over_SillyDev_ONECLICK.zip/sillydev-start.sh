#!/usr/bin/env bash
set -e
export NODE_ENV=production
mkdir -p data/sessions/main logs
exec node index.js
