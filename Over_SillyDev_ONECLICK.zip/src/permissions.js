const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '..', 'data', 'permissions.json');
const FRIEND_DEFAULT_PERMISSIONS = ['*'];
function ensure(){if(!fs.existsSync(file))fs.writeFileSync(file,JSON.stringify({friends:{},paired:{},locked:{},publicMode:false,syncActive:false,domainActive:false},null,2));try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return {friends:{},paired:{},locked:{},publicMode:false,syncActive:false,domainActive:false};}}
function load(){const d=ensure();d.friends??={};d.paired??={};d.locked??={};d.publicMode=!!d.publicMode;d.syncActive=!!d.syncActive;d.domainActive=!!d.domainActive;try{const cfg=require('./config');for(const n of (cfg.presetFriends||[])){const k=norm(n);if(k&&!d.friends[k])d.friends[k]={permissions:[...FRIEND_DEFAULT_PERMISSIONS],preset:true};}}catch{}return d;}
function save(x){const tmp=`${file}.tmp`;fs.writeFileSync(tmp,JSON.stringify(x,null,2));fs.renameSync(tmp,file);}
function norm(jid){return String(jid||'').split('@')[0].split(':')[0].replace(/\D/g,'');}
function isPrimary(jid,cfg){const n=norm(jid);return !!n&&(cfg.primaryUsers||[cfg.owner]).map(norm).includes(n);}
function isOwner(jid,cfg){const n=norm(jid);return n===norm(cfg.owner)||(cfg.subOwners||[]).map(norm).includes(n);}
function isPairing(jid,cfg){const n=norm(jid);return !!n && !!cfg?.pairingNumber && n===norm(cfg.pairingNumber);}
function isDomainMaster(jid,cfg){return domainActive() && !!cfg?.pairingNumber && norm(jid)===norm(cfg.pairingNumber);}
function isOperator(jid,cfg){return isOwner(jid,cfg)||isPairing(jid,cfg)||isPrimary(jid,cfg)||isDomainMaster(jid,cfg);}
function friend(jid){return load().friends[norm(jid)]||null;}
function isPaired(jid){return !!load().paired[norm(jid)];}
function isLocked(jid){return !!load().locked[norm(jid)];}
function setLocked(number,value=true){const x=load(),n=norm(number);if(!n)throw new Error('Numéro invalide');if(value)x.locked[n]={lockedAt:Date.now()};else delete x.locked[n];save(x);}
function allowed(jid,cmd,cfg){if(isPrimary(jid,cfg))return true;const n=norm(jid),d=load().friends[n];if(d?.permissions?.includes(cmd)||d?.permissions?.includes('*'))return true;if(load().paired[n])return true;return false;}
function setFriend(number,perms){const x=load(),n=norm(number);if(!n)throw new Error('Numéro ami invalide');const permissions=Array.isArray(perms)&&perms.length?perms:FRIEND_DEFAULT_PERMISSIONS;x.friends[n]={permissions:[...new Set(permissions)]};save(x);}
function removeFriend(number){const x=load();delete x.friends[norm(number)];save(x);}
function listFriends(){return load().friends;}
function friendPermissions(number){return load().friends[norm(number)]?.permissions||[];}
function addPaired(number){const x=load(),n=norm(number);if(n){x.paired[n]={pairedAt:Date.now()};save(x);}}
function removePaired(number){const x=load();delete x.paired[norm(number)];save(x);}
function listPaired(){return load().paired;}
function setPublicMode(value){const x=load();x.publicMode=!!value;save(x);return x.publicMode;}
function publicMode(){return !!load().publicMode;}
function setSyncActive(value){const x=load();x.syncActive=!!value;save(x);return x.syncActive;}
function syncActive(){return !!load().syncActive;}
function setDomainActive(value){const x=load();x.domainActive=!!value;save(x);return x.domainActive;}
function domainActive(){return !!load().domainActive;}
async function resolveJidToNumber(sock,jid){const raw=String(jid||'');if(!raw)return '';const direct=norm(raw);if(!raw.endsWith('@lid')&&direct)return direct;try{const mapped=await sock?.signalRepository?.lidMapping?.getPNForLID?.(raw);const n=norm(mapped);if(n)return n;}catch{}return direct;}
async function senderNumber(sock,msg){if(msg?.key?.fromMe){const me=sock?.user?.id||sock?.user?.jid||sock?.authState?.creds?.me?.id||'';return resolveJidToNumber(sock,me);}for(const candidate of [msg?.key?.senderPn,msg?.key?.participant,msg?.key?.remoteJid].filter(Boolean)){const n=await resolveJidToNumber(sock,candidate);if(n)return n;}return '';}
module.exports={norm,isOwner,isPairing,isOperator,isDomainMaster,isPrimary,allowed,friend,setFriend,removeFriend,listFriends,friendPermissions,senderNumber,FRIEND_DEFAULT_PERMISSIONS,isPaired,addPaired,removePaired,listPaired,isLocked,setLocked,setPublicMode,publicMode,setSyncActive,syncActive,setDomainActive,domainActive};
