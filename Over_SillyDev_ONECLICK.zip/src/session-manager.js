const fs = require('fs');
const path = require('path');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');

const sessions = new Map();
const reconnectTimers = new Map();
const base = path.join(__dirname, '..', 'data', 'sessions');
// NON-DESTRUCTIVE POLICY: this manager never deletes auth files/directories.
const AUTO_DELETE_SESSIONS = false;
fs.mkdirSync(base, { recursive: true });

async function startSession(id, logger, opts = {}) {
  if (!id) throw new Error('Session id manquant');
  if (sessions.has(id)) return sessions.get(id);
  const dir = path.join(base, String(id).replace(/[^a-zA-Z0-9_-]/g, '_'));
  fs.mkdirSync(dir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(dir);
  const sock = makeWASocket({ auth: state, printQRInTerminal: false, logger, syncFullHistory: false, shouldSyncHistoryMessage: () => false });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', update => {
    if (update.connection === 'open') console.log(`[SYNC] ${id} connecté`);
    if (update.connection !== 'close') return;
    sessions.delete(id);
    const code = update.lastDisconnect?.error?.output?.statusCode;
    if (code === DisconnectReason.loggedOut) {
      console.log(`[SYNC] ${id} : session conservée. Suppression automatique désactivée.`);
      return;
    }
    if (opts.autoReconnect === false) return;
    if (reconnectTimers.has(id)) return;
    const timer = setTimeout(() => {
      reconnectTimers.delete(id);
      startSession(id, logger, opts).catch(err => console.error(`[SYNC] ${id} :`, err?.stack || err));
    }, opts.reconnectDelayMs || 3000);
    reconnectTimers.set(id, timer);
  });
  sessions.set(id, sock);
  return sock;
}

function list() { return [...sessions.keys()]; }
function stop(id) {
  const timer = reconnectTimers.get(id);
  if (timer) { clearTimeout(timer); reconnectTimers.delete(id); }
  const s = sessions.get(id);
  if (s) { try { s.end?.(new Error('stopped')); } catch {} sessions.delete(id); } // memory only; never delete auth files
}

module.exports = { startSession, list, stop, sessions };
