const pino = require('pino');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
} = require('@whiskeysockets/baileys');
const cfg = require('./config');
const { handle, antiMiddleware, antiCallMiddleware, handleParticipantUpdate, handleStatusMention, autoReactMiddleware } = require('./commands');
const { senderNumber, isPrimary, friend } = require('./permissions');
const subsessions = require('./subsessions');
const path = require('path');
const fs = require('fs');
const readline = require('readline');

function normalizePhone(value) {
  return String(value || '').replace(/\D/g, '');
}

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, answer => { rl.close(); resolve(answer); }));
}

async function prepareSelectedSession(number) {
  // Si une session principale existe déjà pour un autre numéro, on l'archive au lieu de
  // l'écraser. Cela permet de changer librement le numéro de connexion sans toucher
  // aux données du bot ni à l'identité propriétaire.
  const credsPath = path.join(MAIN_AUTH, 'creds.json');
  if (!fs.existsSync(credsPath)) return MAIN_AUTH;
  try {
    const creds = JSON.parse(fs.readFileSync(credsPath, 'utf8'));
    const current = normalizePhone(creds?.me?.id || creds?.me?.jid || '');
    if (!current || current === number) return MAIN_AUTH;
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const archiveDir = path.join(SESSION_BASE, `previous-${current}-${stamp}`);
    fs.renameSync(MAIN_AUTH, archiveDir);
    fs.mkdirSync(MAIN_AUTH, { recursive: true });
    console.log('♻️ Ancienne session de connexion archivée.');
  } catch (err) {
    console.log('⚠️ Impossible de lire la session précédente ; elle sera conservée.');
  }
  return MAIN_AUTH;
}

const SESSION_BASE = path.join(__dirname, '..', 'data', 'sessions');
const MAIN_AUTH = path.join(SESSION_BASE, 'main');
const RECOVERY_ROOT = path.join(SESSION_BASE, 'pairing-recovery');
fs.mkdirSync(MAIN_AUTH, { recursive: true });
fs.mkdirSync(RECOVERY_ROOT, { recursive: true });

const RETRY_DELAYS = [1500, 3000, 6000, 12000, 20000, 30000, 45000, 60000];
let retryCount = 0;
let retryTimer = null;
let socket = null;
let starting = false;
let stopped = false;
let heartbeat = null;
let healthMonitor = null;
let connectionWatchdog = null;
let connectionState = 'starting';
let lastConnectionEventAt = Date.now();
let lastConnectionOpenAt = 0;
let recoveryMode = false;
let currentAuthDir = MAIN_AUTH;
let recoveryGeneration = 0;
let freshPairAttempted = false;
const silentPairing = true;
let pairingWasRequested = false;
let credsSaveChain = Promise.resolve();

const statusCodeOf = err => err?.output?.statusCode ?? err?.statusCode ?? err?.data?.statusCode;

function statusText(code) {
  const map = {
    [DisconnectReason.restartRequired]: 'redémarrage demandé par WhatsApp (515)',
    [DisconnectReason.connectionLost]: 'connexion réseau interrompue',
    [DisconnectReason.connectionClosed]: 'connexion fermée temporairement',
    [DisconnectReason.timedOut]: 'délai réseau dépassé',
    [DisconnectReason.loggedOut]: 'session révoquée par WhatsApp (401)',
    [DisconnectReason.badSession]: 'session invalide (500)',
    [DisconnectReason.connectionReplaced]: 'connexion remplacée (440)',
  };
  return map[code] || (code == null ? 'connexion interrompue' : `code ${code}`);
}

function logError(label, err) {
  console.error(`❌ ${label}`);
  console.error(err?.stack || err?.message || err);
}

function ownNumbers(sock) {
  const ids = [sock?.user?.id, sock?.user?.lid, sock?.user?.jid, sock?.authState?.creds?.me?.id];
  return [...new Set(ids.flatMap(value => {
    if (!value) return [];
    const n = String(value).split('@')[0].split(':')[0].replace(/\D/g, '');
    return n ? [n] : [];
  }))];
}

async function saveCredentials(saveCreds) {
  // Serialize credential writes. This is important around the 515 restart.
  credsSaveChain = credsSaveChain.then(() => saveCreds()).catch(err => logError('Sauvegarde credentials', err));
  await credsSaveChain;
}

async function requestPairing(sock, state) {
  if (!sock || state.creds.registered || pairingWasRequested || stopped) return;
  pairingWasRequested = true;
  try {
    const number = String(cfg.pairingNumber).replace(/\D/g, '');
    if (!/^\d{8,15}$/.test(number)) throw new Error(`PAIRING_NUMBER invalide: ${number}`);
    const code = await sock.requestPairingCode(number);
    console.log('\n╔════════════════════════════════════════════╗');
    console.log('║          🔐 APPAIRAGE DE OVER             ║');
    console.log('╠════════════════════════════════════════════╣');
    console.log(`║ 📱 NUMÉRO DE CONNEXION : ${number}`);
    console.log(`║ 🔑 CODE   : ${code}`);
    console.log('║');
    console.log('║ WhatsApp → Appareils connectés →');
    console.log('║ Connecter avec un numéro de téléphone.');
    console.log('╚════════════════════════════════════════════╝\n');
  } catch (err) {
    pairingWasRequested = false;
    logError('Génération du code de jumelage', err);
    // Do not immediately reconnect and spam pairing requests.
    console.log('⏸️ Nouvelle demande de code en attente de la prochaine initialisation WhatsApp.');
  }
}

function clearConnectionTimers() {
  if (heartbeat) { clearInterval(heartbeat); heartbeat = null; }
  if (healthMonitor) { clearInterval(healthMonitor); healthMonitor = null; }
  if (connectionWatchdog) { clearTimeout(connectionWatchdog); connectionWatchdog = null; }
}

function armHealthMonitor(sock) {
  if (healthMonitor) clearInterval(healthMonitor);
  healthMonitor = setInterval(() => {
    if (stopped || socket !== sock) return;
    const age = Date.now() - lastConnectionEventAt;
    const wsState = sock?.ws?.readyState;
    // WebSocket.OPEN = 1. If Baileys/Node loses the socket without emitting a useful
    // event, force the normal reconnect path instead of leaving a dead process alive.
    if (connectionState === 'open' && wsState !== undefined && wsState !== 1) {
      console.log('🩺 Surveillance : socket WhatsApp inactive, relance contrôlée.');
      try { sock?.ws?.close?.(); } catch {}
      return;
    }
    if (connectionState !== 'open' && age > 180000) {
      console.log('🩺 Surveillance : connexion bloquée depuis 180 s, nouvelle tentative.');
      try { sock?.ws?.close?.(); } catch {}
    }
  }, 45000);
}


function armConnectionWatchdog(sock, authDir) {
  if (connectionWatchdog) clearTimeout(connectionWatchdog);
  connectionWatchdog = setTimeout(() => {
    connectionWatchdog = null;
    if (stopped || socket !== sock) return;
    console.log('⏱️ Connexion bloquée trop longtemps : redémarrage contrôlé de la socket.');
    try { sock?.ws?.close?.(); } catch {}
  }, 90000);
}

function scheduleReconnect(code, authDir, wasRegistered) {
  if (stopped || retryTimer) return;

  // All transient WhatsApp/network disconnects are retried automatically.
  // Only loggedOut/badSession require a fresh pairing; they are handled below.
  if (code === DisconnectReason.restartRequired) {
    // 515 is expected after successful pairing: reopen the same auth directory immediately.
    retryTimer = setTimeout(() => {
      retryTimer = null;
      currentAuthDir = authDir;
      start(authDir).catch(err => logError('Reconnexion 515', err));
    }, 0);
    console.log('♻️ 515 reçu : redémarrage immédiat avec les credentials sauvegardés.');
    return;
  }

  if (code === DisconnectReason.loggedOut || code === DisconnectReason.badSession) {
    // 401/500 means the saved WhatsApp credentials are no longer accepted.
    // Never create a fresh pairing automatically: doing so can cause repeated
    // 8-character codes and is not a valid way to bypass a WhatsApp revocation.
    console.log(`🛑 ${statusText(code)}.`);
    console.log('⏸️ Session conservée. Aucun nouveau code de jumelage ne sera généré automatiquement.');
    console.log('📱 Si WhatsApp a réellement révoqué l’appareil, un nouveau jumelage manuel sera nécessaire.');
    clearConnectionTimers();
    socket = null;
    return;
  }

  const transientCodes = new Set([
    DisconnectReason.connectionClosed,
    DisconnectReason.connectionLost,
    DisconnectReason.timedOut,
    DisconnectReason.connectionReplaced,
  ]);
  const delay = transientCodes.has(code)
    ? RETRY_DELAYS[Math.min(retryCount, RETRY_DELAYS.length - 1)]
    : RETRY_DELAYS[Math.min(retryCount, RETRY_DELAYS.length - 1)];
  retryCount += 1;
  if (!silentPairing) console.log(`♻️ ${statusText(code)}. Nouvelle tentative dans ${Math.ceil(delay / 1000)} s...`);
  retryTimer = setTimeout(() => {
    retryTimer = null;
    start(currentAuthDir).catch(err => logError('Reconnexion', err));
  }, delay);
}

async function start(authDir = currentAuthDir) {
  if (starting || stopped) return;
  starting = true;
  currentAuthDir = authDir;
  const logger = pino({ level: cfg.logLevel });

  try {
    const { state, saveCreds } = await useMultiFileAuthState(authDir);
    pairingWasRequested = state.creds.registered;

    connectionState = 'starting';
    lastConnectionEventAt = Date.now();
    socket = makeWASocket({
      auth: state,
      logger,
      browser: Browsers.windows('Chrome'),
      printQRInTerminal: false,
      // Allows WhatsApp phone notifications while keeping the socket connected.
      markOnlineOnConnect: false,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 60000,
      keepAliveIntervalMs: 15000,
      syncFullHistory: false,
      fireInitQueries: true,
      generateHighQualityLinkPreview: false,
      shouldIgnoreJid: jid => jid === 'status@broadcast',
    });

    socket.ev.on('creds.update', () => saveCredentials(saveCreds));

    armConnectionWatchdog(socket, authDir);

    socket.ev.on('connection.update', async update => {
      try {
        const { connection, lastDisconnect, qr, isNewLogin } = update;
        lastConnectionEventAt = Date.now();
        const code = statusCodeOf(lastDisconnect?.error);

        if (isNewLogin) {
          // Pairing can emit 515 before connection=open. Treat the new login as proof that
          // credentials have been created, so the next socket must use the same auth folder.
          recoveryMode = false;
          pairingWasRequested = true;
          await saveCredentials(saveCreds);
          console.log('🔐 Nouveau login WhatsApp reçu : credentials sauvegardés.');
        }

        if (!state.creds.registered && qr) {
          await requestPairing(socket, state);
        }

        if (connection === 'open') {
          connectionState = 'open';
          retryCount = 0;
          lastConnectionOpenAt = Date.now();
          if (connectionWatchdog) { clearTimeout(connectionWatchdog); connectionWatchdog = null; }
          recoveryMode = authDir !== MAIN_AUTH;
          pairingWasRequested = true;
          await saveCredentials(saveCreds);
          console.log(`\n💀 ${cfg.name} v${cfg.version} EN LIGNE`);
          console.log('🔐 Connexion : numéro sélectionné au démarrage.');
          console.log(`🆔 Identités : ${ownNumbers(socket).join(', ') || 'en attente'}`);
          if (heartbeat) clearInterval(heartbeat);
          const connectedSocket = socket;
          armHealthMonitor(connectedSocket);
          heartbeat = setInterval(() => {
            if (stopped || socket !== connectedSocket) return;
            console.log('💚 Over actif — session persistante + reconnexion automatique.');
          }, 60000);
        }

        if (connection === 'close') {
          connectionState = 'closed';
          clearConnectionTimers();
          await saveCredentials(saveCreds);
          const oldSocket = socket;
          socket = null;
          try { oldSocket?.ws?.close?.(); } catch {}

          // If pairing succeeded, state.creds.registered/isNewLogin will be persisted and
          // 515 must restart using the same auth directory. Do not request a second code.
          if (code === DisconnectReason.restartRequired && !state.creds.registered && !isNewLogin) {
            console.log('⏸️ WhatsApp demande un redémarrage avant validation. Nouvelle tentative contrôlée, sans boucle de codes.');
            pairingWasRequested = false;
            return;
          }
          scheduleReconnect(code, authDir, Boolean(state.creds.registered || isNewLogin));
        }
      } catch (err) {
        logError('Événement de connexion', err);
      }
    });

    socket.ev.on('call', async calls => {
      try { await antiCallMiddleware(socket, calls, cfg); }
      catch (err) { logError('Protection anti-call', err); }
    });

    socket.ev.on('group-participants.update', async update => {
      try { await handleParticipantUpdate(socket, update, cfg); }
      catch (err) { logError('Protection anti-promote/anti-demote', err); }
    });

    socket.ev.on('messages.upsert', async event => {
      for (const message of (Array.isArray(event?.messages) ? event.messages : [])) {
        try {
          if (!message?.key || !message.message) continue;
          const jid = message.key.remoteJid;
          if (!jid) continue;
          if (jid === 'status@broadcast') {
            await handleStatusMention(socket, message, cfg);
            continue;
          }
          const text = getMessageText(message);

          // Les protections et la réaction automatique doivent voir TOUS les messages
          // du groupe, pas seulement ceux qui commencent par le préfixe.
          await autoReactMiddleware(socket, message, cfg);
          if (await antiMiddleware(socket, message, cfg)) continue;

          // Seuls les messages avec préfixe sont ensuite envoyés au gestionnaire de commandes.
          // Les messages normaux peuvent toutefois servir aux jeux actifs.
          if (!text.startsWith(cfg.prefix)) {
            if (!message.key.fromMe) {
              try { await handle(socket, message, cfg, logger, { subsessions }); } catch {}
            }
            continue;
          }

          // Le gestionnaire effectue lui-même le contrôle d'accès et la résolution LID/P-N.
          await handle(socket, message, cfg, logger, { subsessions });
        } catch (err) {
          logger.error({ err, jid: message?.key?.remoteJid, messageId: message?.key?.id }, 'Erreur dans le gestionnaire de message');
          logError(`Message ${message?.key?.id || 'unknown'}`, err);
        }
      }
    });
  } catch (err) {
    logError('Démarrage', err);
    socket = null;
    const detectedCode = statusCodeOf(err) || (String(err?.message || err).match(/\b(401|500)\b/)?.[1] && Number(String(err?.message || err).match(/\b(401|500)\b/)[1]));
    scheduleReconnect(detectedCode, authDir, false);
  } finally {
    starting = false;
  }
}

function unwrapMessage(message) {
  let m = message?.message || {};
  for (let i = 0; i < 6; i++) {
    const next = m?.ephemeralMessage?.message || m?.viewOnceMessage?.message || m?.viewOnceMessageV2?.message || m?.documentWithCaptionMessage?.message;
    if (!next) break;
    m = next;
  }
  return m || {};
}

function getMessageText(message) {
  const m = unwrapMessage(message);
  return String(m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || '').trim();
}

process.on('uncaughtException', err => {
  logError('Exception non interceptée récupérée', err);
  // Silly Dev redémarre automatiquement un processus terminé. Exiting is safer than
  // leaving a partially corrupted WhatsApp socket alive for hours.
  setTimeout(() => process.exit(1), 1500).unref();
});
process.on('unhandledRejection', err => {
  logError('Promesse non interceptée récupérée', err);
});
process.once('SIGTERM', () => {
  stopped = true;
  if (retryTimer) clearTimeout(retryTimer);
  clearConnectionTimers();
  try { socket?.ws?.close?.(); } catch {}
});
process.once('SIGINT', () => {
  stopped = true;
  if (retryTimer) clearTimeout(retryTimer);
  clearConnectionTimers();
  try { socket?.ws?.close?.(); } catch {}
});

(async () => {
  try {
    // Silly Dev : aucun prompt interactif. Le compte de connexion est fixe.
    const number = String(cfg.pairingNumber).replace(/\D/g, '');
    const authDir = await prepareSelectedSession(number);
    await start(authDir);
  } catch (err) {
    logError('Erreur de démarrage récupérée', err);
  }
})();
