const fs = require('fs');
const path = require('path');
const { isOwner, isPairing, isOperator, isDomainMaster, isPrimary, allowed, setFriend, removeFriend, listFriends, friendPermissions, norm, FRIEND_DEFAULT_PERMISSIONS, senderNumber, isLocked, setLocked, setPublicMode, publicMode, setSyncActive, syncActive, setDomainActive, domainActive, addPaired, removePaired } = require('./permissions');

let PREFIX = process.env.BOT_PREFIX || '!';
const PREFIX_FILE = path.join(__dirname, '..', 'data', 'bot-config.json');
function savePrefix(value) {
  const tmp = `${PREFIX_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify({ prefix: value }, null, 2));
  fs.renameSync(tmp, PREFIX_FILE);
}
function normalizePrefix(value) {
  const v = String(value || '').trim();
  if (!v || v.length > 3 || /\s/.test(v)) return null;
  return v;
}
const DATA = path.join(__dirname, '..', 'data');
const files = {
  anti: path.join(DATA, 'anti.json'), warnings: path.join(DATA, 'warnings.json'), botWarnings: path.join(DATA, 'bot-warnings.json'),
  botActivity: path.join(DATA, 'bot-activity.json'), kickActivity: path.join(DATA, 'kick-activity.json'), spam: path.join(DATA, 'spam-activity.json'), games: path.join(DATA, 'games.json'),
  locks: path.join(DATA, 'locks.json'), settings: path.join(DATA, 'settings.json'), economy: path.join(DATA, 'economy.json'),
  reminders: path.join(DATA, 'reminders.json'),
};
fs.mkdirSync(DATA, { recursive: true });
for (const f of Object.values(files)) if (!fs.existsSync(f)) fs.writeFileSync(f, '{}');

const SPAM_MAX_MESSAGES = Math.max(1, Number(process.env.ANTISPAM_MAX_MESSAGES || 5));
const SPAM_WINDOW_MS = Math.max(1, Number(process.env.ANTISPAM_WINDOW_MS || 500));
const DEFAULT_ANTI = { antilink:false, antispam:false, antisticker:false, antiaudio:false, antivideo:false, antimention:false, antistatut:false, antiimage:false, antibot:false, antitag:false, antitagall:false, antikickall:false, antiviewonce:false, antidemote:false, antipromote:false, antiban:false, groupguard:false, anticall:false };

function read(file, fallback = {}) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function write(file, value) { const tmp = `${file}.tmp`; fs.writeFileSync(tmp, JSON.stringify(value, null, 2)); fs.renameSync(tmp, file); }
function senderId(msg, sock) { if (msg?.key?.fromMe) return sock?.user?.id || sock?.user?.jid || msg?.key?.participant || msg?.key?.remoteJid || ''; return msg?.key?.participant || msg?.key?.remoteJid || ''; }
function isGroup(jid) { return typeof jid === 'string' && jid.endsWith('@g.us'); }
function unwrap(msg) { let m = msg?.message || {}; for (let i=0;i<6;i++) { const n=m?.ephemeralMessage?.message||m?.viewOnceMessage?.message||m?.viewOnceMessageV2?.message||m?.documentWithCaptionMessage?.message; if(!n) break; m=n; } return m; }
function messageText(msg) { const m=unwrap(msg); return String(m.conversation||m.extendedTextMessage?.text||m.imageMessage?.caption||m.videoMessage?.caption||m.documentMessage?.caption||'').trim(); }
function quoted(msg) { return msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null; }
function mentions(msg) { return msg?.message?.extendedTextMessage?.contextInfo?.mentionedJid || []; }
function targetJid(msg, sock, args=[]) { return mentions(msg)[0] || (args[0] && /^\d{6,15}$/.test(args[0].replace(/\D/g,'')) ? `${args[0].replace(/\D/g,'')}@s.whatsapp.net` : null) || quoted(msg)?.key?.participant || null; }
function antiSettings(jid) { const a=read(files.anti); return a[jid] || { ...DEFAULT_ANTI }; }
function setAnti(jid,key,val) { const a=read(files.anti); a[jid] = { ...DEFAULT_ANTI, ...(a[jid]||{}), [key]:val }; write(files.anti,a); }
function addWarning(jid,user){const w=read(files.warnings);w[jid]=w[jid]||{};w[jid][user]=(w[jid][user]||0)+1;write(files.warnings,w);return w[jid][user];}
function clearWarning(jid,user){const w=read(files.warnings);if(w[jid]){delete w[jid][user];write(files.warnings,w);}}
function addBotWarning(jid,user){const w=read(files.botWarnings);w[jid]=w[jid]||{};w[jid][user]=(w[jid][user]||0)+1;write(files.botWarnings,w);return w[jid][user];}
function clearBotWarning(jid,user){const w=read(files.botWarnings);if(w[jid]){delete w[jid][user];write(files.botWarnings,w);}}
function recordActivity(file,jid,user,windowMs){const a=read(file);a[jid]=a[jid]||{};const now=Date.now();const arr=(a[jid][user]||[]).filter(t=>now-t<windowMs);arr.push(now);a[jid][user]=arr;write(file,a);return arr.length;}
function clearActivity(file,jid,user){const a=read(file);if(a[jid]){delete a[jid][user];write(file,a);}}
function extractLinks(text){return /(https?:\/\/|www\.|chat\.whatsapp\.com\/|t\.me\/|discord\.gg\/)/i.test(text);}
function detectType(msg){const m=unwrap(msg);if(m.imageMessage)return'image';if(m.videoMessage)return'video';if(m.audioMessage)return'audio';if(m.stickerMessage)return'sticker';return null;}
function mentionCount(msg){return mentions(msg).length;}
async function metadata(sock,jid){try{return await sock.groupMetadata(jid);}catch{return null;}}
function sameJid(a,b){
  const aa=String(a||'').split(':')[0].toLowerCase();
  const bb=String(b||'').split(':')[0].toLowerCase();
  if(!aa||!bb) return false;
  if(aa===bb) return true;
  const an=aa.replace(/\D/g,''); const bn=bb.replace(/\D/g,'');
  return !!an && !!bn && an===bn;
}
function isAdmin(meta,user){
  const u=String(user||'');
  if(!u) return false;
  return !!meta?.participants?.some(p=>sameJid(p?.id,u)&&(p?.admin==='admin'||p?.admin==='superadmin'));
}
async function resolvePN(sock,jid){
  if(!jid) return '';
  const raw=String(jid);
  if(!raw.endsWith('@lid')) return raw;
  try {
    const mapped=await sock?.signalRepository?.lidMapping?.getPNForLID?.(raw);
    if(mapped) return String(mapped);
  } catch {}
  return raw;
}
async function isAdminAsync(meta,user,sock){
  if(isAdmin(meta,user)) return true;
  const resolved=await resolvePN(sock,user);
  if(resolved && isAdmin(meta,resolved)) return true;
  const pn=norm(resolved), raw=norm(user);
  if(pn && meta?.participants?.some(p=>norm(p?.id)===pn&&(p?.admin==='admin'||p?.admin==='superadmin'))) return true;
  if(raw && meta?.participants?.some(p=>norm(p?.id)===raw&&(p?.admin==='admin'||p?.admin==='superadmin'))) return true;
  return false;
}
async function botIdentityCandidates(sock){
  const me=sock?.authState?.creds?.me||{};
  const ids=[sock?.user?.id,sock?.user?.lid,sock?.user?.jid,me?.id,me?.lid].filter(Boolean).map(String);
  const out=[];
  for(const id of ids){
    out.push(id);
    const r=await resolvePN(sock,id);
    if(r) out.push(r);
  }
  return [...new Set(out)];
}
async function botIsAdmin(meta,sock){
  if(!meta?.participants?.length) return false;
  const ids=await botIdentityCandidates(sock);
  return meta.participants.some(p=>{
    if(p?.admin!=='admin'&&p?.admin!=='superadmin') return false;
    return ids.some(id=>sameJid(p?.id,id)||norm(p?.id)===norm(id));
  });
}
function canonicalUserJid(sock,msg){
  const raw=senderId(msg,sock);
  if(raw && !raw.endsWith('@lid')) return raw;
  return raw;
}
function displayName(meta,user){const p=meta?.participants?.find(x=>x.id===user);return p?.notify||p?.name||user.split('@')[0];}
function normText(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();}
const DEFAULT_REACTION='❤️';
function reactionSettings(jid){const s=read(files.settings);return s[jid]?.autoReact||{enabled:false,emoji:DEFAULT_REACTION};}
function setReactionSettings(jid,patch){const s=read(files.settings);s[jid]=s[jid]||{};s[jid].autoReact={...reactionSettings(jid),...patch};write(files.settings,s);return s[jid].autoReact;}
function isReactionMessage(msg){const m=unwrap(msg);return !!m?.reactionMessage;}
async function autoReactMiddleware(sock,msg,cfg){const jid=msg?.key?.remoteJid;if(!jid||jid==='status@broadcast'||!isGroup(jid)||msg?.key?.fromMe||isReactionMessage(msg))return false;const st=reactionSettings(jid);if(!st.enabled)return false;const text=messageText(msg);const hasMention=mentions(msg).length>0||/@[0-9]{5,}/.test(text)||/@(?:everyone|all)\b/i.test(text);if(!hasMention)return false;try{await sock.sendMessage(jid,{react:{text:st.emoji||DEFAULT_REACTION,key:msg.key}});}catch{}return false;}

function menu(){return `╭────────────────────────────────────╮
│              ✦ 𝐎𝐕𝐄𝐑 ✦             │
│          5.1 • DEATH EDITION         │
╰────────────────────────────────────╯
        ◈ 𝗠𝗢𝗗𝗘 𝗡𝗘𝗫𝗧 • 𝗖𝗟𝗘𝗔𝗡 • 𝗙𝗔𝗦𝗧 ◈

  ⟡ Préfixe actuel : ${PREFIX}

╭─〔 ⚡ 𝗘𝗦𝗦𝗘𝗡𝗧𝗜𝗘𝗟 〕──────────────╮
│ ${PREFIX}menu       • interface
│ ${PREFIX}help       • aide
│ ${PREFIX}ping       • test
│ ${PREFIX}setprefix  • changer le préfixe
╰────────────────────────────────────╯

╭─〔 👥 𝗚𝗥𝗢𝗨𝗣𝗘 〕──────────────────╮
│ ${PREFIX}kick @membre    ${PREFIX}promote @membre
│ ${PREFIX}demote @admin   ${PREFIX}mute / ${PREFIX}unmute
│ ${PREFIX}tag / ${PREFIX}tagall / ${PREFIX}hidetag
│ ${PREFIX}grouplink  ${PREFIX}clean  ${PREFIX}poll
│ ${PREFIX}welcome on/off  ${PREFIX}goodbye on/off
╰────────────────────────────────────╯

╭─〔 🛡️ 𝗔𝗡𝗧𝗜 〕────────────────────╮
│ ${PREFIX}antit on/off/status  • toutes les protections
│ ${PREFIX}anticall on/off      • bloque les appels
│ ${PREFIX}anti status
│ ${PREFIX}anti link|spam|image|video|audio on/off
│ ${PREFIX}anti sticker|bot|tag|tagall|mention on/off
│ ${PREFIX}anti kickall|promote|demote on/off
╰────────────────────────────────────╯

╭─〔 💫 𝗥𝗘́𝗔𝗖𝗧𝗜𝗢𝗡 〕──────────────╮
│ ${PREFIX}autoreact on/off
│ ${PREFIX}autoreact set ❤️
│ Réagit automatiquement aux messages contenant @
╰────────────────────────────────────╯

╭─〔 📥 𝗠𝗘́𝗗𝗜𝗔 & 🔎 𝗥𝗘𝗖𝗛𝗘𝗥𝗖𝗛𝗘 〕────╮
│ ${PREFIX}play  ${PREFIX}youtube  ${PREFIX}tiktok  ${PREFIX}facebook
│ ${PREFIX}sticker  ${PREFIX}tomp3  ${PREFIX}vv
│ ${PREFIX}search  ${PREFIX}movie  ${PREFIX}wallpaper  ${PREFIX}img
│ ${PREFIX}translate <texte>  ${PREFIX}termux_tools <recherche>
╰────────────────────────────────────╯

╭─〔 🎮 𝗝𝗘𝗨𝗫 〕───────────────────╮
│ ${PREFIX}quiz <thème> @membre @membre
│ ${PREFIX}quiz points <nombre>  ${PREFIX}quiz status
│ ${PREFIX}game  ${PREFIX}rps  ${PREFIX}guess
│ ${PREFIX}hangman  ${PREFIX}8ball  ${PREFIX}coinflip  ${PREFIX}roll
╰────────────────────────────────────╯

╭─〔 🤝 𝗙𝗥𝗜𝗘𝗡𝗗 〕─────────────────╮
│ ${PREFIX}friend @membre  • donner l'accès aux commandes
│ ${PREFIX}friend remove @membre
│ ${PREFIX}addprem <numéro>  ${PREFIX}delprem <numéro>
│ ${PREFIX}listowner  ${PREFIX}listpremium
╰────────────────────────────────────╯

╭─〔 🌐 𝗗𝗢𝗠𝗔𝗜𝗡𝗘 〕────────────────╮
│ ${PREFIX}domaine on/off/status
│ Le premier numéro du panneau devient le contrôleur
│ des sous-sessions lorsque le domaine est actif.
╰────────────────────────────────────╯

          ✦ 𝐎𝐕𝐄𝐑 • 𝗦𝗧𝗬𝗟𝗘 𝗠𝗢𝗗𝗘 ✦`; }
async function deleteMessage(sock,msg){try{if(msg?.key?.remoteJid&&msg?.key?.id)await sock.sendMessage(msg.key.remoteJid,{delete:msg.key});}catch(e){}}

async function moderate(sock,msg,cfg,reason){
  const jid=msg?.key?.remoteJid; if(!isGroup(jid)) return false;
  const meta=await metadata(sock,jid); if(!meta || !(await botIsAdmin(meta,sock))) return false;
  const actionJid=canonicalUserJid(sock,msg);
  const number=await senderNumber(sock,msg);
  const user=number?`${number}@s.whatsapp.net`:actionJid;
  if(!actionJid || isOperator(user,cfg) || isOperator(actionJid,cfg) || await isAdminAsync(meta,actionJid,sock) || await isAdminAsync(meta,user,sock)) return false;
  await deleteMessage(sock,msg);
  const count=addWarning(jid,user);
  await sock.sendMessage(jid,{text:`⚠️ @${user.split('@')[0]} avertissement ${count}/3 — ${reason}`,mentions:[user]});
  if(count>=3){
    try{
      await sock.groupParticipantsUpdate(jid,[actionJid],'remove');
      clearWarning(jid,user);
      await sock.sendMessage(jid,{text:`🚫 @${user.split('@')[0]} a atteint 3 avertissements et a été retiré.`,mentions:[user]});
    }catch{
      try{ if(actionJid!==user) await sock.groupParticipantsUpdate(jid,[user],'remove'); clearWarning(jid,user); }catch{}
      await sock.sendMessage(jid,{text:'⚠️ 3 avertissements atteints, mais retrait impossible : vérifie les droits administrateur.'});
    }
  }
  return true;
}


async function handleParticipantUpdate(sock, update, cfg){
  const jid=update?.id; if(!isGroup(jid)) return;
  const s=antiSettings(jid);
  const action=String(update?.action||'').toLowerCase();
  const participants=Array.isArray(update?.participants)?update.participants:[];
  const author=update?.author || '';
  const meta=await metadata(sock,jid); if(!meta||!(await botIsAdmin(meta,sock))) return;
  const botIds=new Set([sock?.user?.id,sock?.user?.lid,sock?.user?.jid].filter(Boolean).map(x=>String(x)));
  const isBotTarget = p => botIds.has(String(p)) || botIds.has(String(p).split(':')[0]+'@s.whatsapp.net');
  const authorIsBot = botIds.has(String(author)) || botIds.has(String(author).split(':')[0]+'@s.whatsapp.net');
  if(authorIsBot) return;

  if(action==='remove' && s.antikickall && author){
    const now=Date.now();const key=`${jid}|${author}`;const activity=read(files.kickActivity);const arr=(activity[key]||[]).filter(t=>now-t<100);arr.push(now);activity[key]=arr;write(files.kickActivity,activity);
    if(arr.length>2 && !isBotTarget(author)){try{await sock.groupParticipantsUpdate(jid,[author],'demote');await sock.sendMessage(jid,{text:`🚫 ANTI-KICK-ALL : ${author.split('@')[0]} a supprimé plus de 2 membres en moins de 100 ms et a été rétrogradé.`});}catch{await sock.sendMessage(jid,{text:'⚠️ ANTI-KICK-ALL : tentative détectée, mais je n’ai pas pu rétrograder l’auteur.'});}activity[key]=[];write(files.kickActivity,activity);}
    return;
  }

  if(action==='promote' && s.antipromote){
    const targets=participants.filter(p=>!isBotTarget(p));
    if(!targets.length) return;
    // Restore the previous state first, then remove the promoter and the newly promoted member.
    try{await sock.groupParticipantsUpdate(jid,targets,'demote');}catch{}
    const remove=[...new Set([...targets, ...(author?[author]:[])])].filter(p=>!isBotTarget(p));
    try{await sock.groupParticipantsUpdate(jid,remove,'remove');
      await sock.sendMessage(jid,{text:`🚫 ANTI-PROMOTE activé. @${String(author).split('@')[0]} a tenté de promouvoir un membre. Le membre promu et l'auteur de la promotion ont été retirés.`,mentions:remove});
    }catch{await sock.sendMessage(jid,{text:'⚠️ ANTI-PROMOTE : tentative bloquée, mais je n’ai pas pu retirer les participants. Vérifie que le bot est administrateur.'});}
    return;
  }

  if(action==='demote' && s.antidemote){
    const targets=participants.filter(p=>!isBotTarget(p));
    if(!targets.length) return;
    // Re-promote every affected administrator. This correction is intentionally isolated from anti-promote.
    try{await sock.groupParticipantsUpdate(jid,targets,'promote');
      await sock.sendMessage(jid,{text:`🛡️ ANTI-DEMOTE activé : ${targets.length>1?'les administrateurs ont été':'l’administrateur a été'} rétabli(s).`});
    }catch{await sock.sendMessage(jid,{text:'⚠️ ANTI-DEMOTE : je n’ai pas pu rétablir l’administrateur. Vérifie mes droits.'});}
  }
}

function statusGroupMentions(msg){
  const found=[];
  const seen=new Set();
  function walk(v,depth=0){
    if(!v||depth>7||typeof v!=='object'||seen.has(v)) return;
    seen.add(v);
    if(Array.isArray(v)){for(const x of v) walk(x,depth+1);return;}
    if(Array.isArray(v.groupMentions)){
      for(const gm of v.groupMentions){
        const jid=gm?.groupJid||gm?.jid||gm?.groupId;
        if(typeof jid==='string'&&jid.endsWith('@g.us')) found.push(jid);
      }
    }
    for(const [k,x] of Object.entries(v)){
      if(k==='key' || k==='messageContextInfo') continue;
      if(x&&typeof x==='object') walk(x,depth+1);
    }
  }
  walk(msg);
  return [...new Set(found)];
}

async function handleStatusMention(sock,msg,cfg){
  if(msg?.key?.remoteJid!=='status@broadcast') return false;
  const groups=statusGroupMentions(msg);
  if(!groups.length) return false;
  const author=msg?.key?.participant || msg?.participant || '';
  if(!author || msg?.key?.fromMe || isOperator(author,cfg)) return false;
  let handled=false;
  for(const jid of groups){
    const s=antiSettings(jid);
    if(!(s.antistatut || s.antimention)) continue;
    const meta=await metadata(sock,jid);
    if(!meta || !(await botIsAdmin(meta,sock))) continue;
    if(await isAdminAsync(meta,author,sock)) continue;
    handled=true;
    const count=addWarning(jid,author);
    await sock.sendMessage(jid,{text:`⚠️ @${author.split('@')[0]} avertissement ${count}/3 — mention du groupe dans un statut interdite.`,mentions:[author]});
    if(count>=3){
      try{
        await sock.groupParticipantsUpdate(jid,[author],'remove');
        clearWarning(jid,author);
        await sock.sendMessage(jid,{text:`🚫 @${author.split('@')[0]} a été retiré après 3 avertissements pour mention du groupe dans un statut.`,mentions:[author]});
      }catch{
        await sock.sendMessage(jid,{text:'⚠️ 3 avertissements atteints, mais retrait impossible : vérifie les droits administrateur.'});
      }
    }
  }
  return handled;
}

async function antiBotMiddleware(sock,msg,cfg){const jid=msg.key.remoteJid;if(!isGroup(jid))return false;const s=antiSettings(jid);if(!s.antibot)return false;const meta=await metadata(sock,jid);if(!meta)return false;const userJid=canonicalUserJid(sock,msg);const userNumber=await senderNumber(sock,msg);const user=userNumber?`${userNumber}@s.whatsapp.net`:userJid;if(msg?.key?.fromMe||isOperator(user,cfg)||await isAdminAsync(meta,user,sock))return false;const activity=recordActivity(files.botActivity,jid,user,15000);const automated=!!(unwrap(msg).buttonsResponseMessage||unwrap(msg).listResponseMessage||unwrap(msg).templateButtonReplyMessage);if(!automated&&activity<5)return false;const count=addBotWarning(jid,user);await sock.sendMessage(jid,{text:`🤖⚠️ Activité automatisée suspecte : @${user.split('@')[0]} — avertissement ${count}/2.`,mentions:[user]});if(count>=2){try{if(await botIsAdmin(meta,sock))await sock.groupParticipantsUpdate(jid,[user],'remove');clearBotWarning(jid,user);}catch{}}return true;}
async function antiCallMiddleware(sock, calls, cfg){
  const list=Array.isArray(calls)?calls:[calls];
  for(const call of list){
    if(!call || call.status!=='offer' || !call.isGroup || !call.groupJid) continue;
    const jid=call.groupJid;
    const s=antiSettings(jid);
    if(!s.anticall) continue;
    try {
      if(typeof sock.rejectCall==='function') await sock.rejectCall(call.id, call.from || call.chatId);
      console.log(`📵 ANTI-CALL : appel de groupe rejeté dans ${jid}`);
    } catch(err) {
      console.log(`⚠️ ANTI-CALL : impossible de rejeter ${call.id}: ${err?.message||err}`);
    }
  }
  return false;
}

async function antiMiddleware(sock,msg,cfg){const jid=msg.key.remoteJid;if(!isGroup(jid))return false;const s=antiSettings(jid),text=messageText(msg),type=detectType(msg);if(await antiBotMiddleware(sock,msg,cfg))return true;const meta=await metadata(sock,jid);if(!meta)return false;const userJid=canonicalUserJid(sock,msg);const userNumber=await senderNumber(sock,msg);const user=userNumber?`${userNumber}@s.whatsapp.net`:userJid;if(!msg?.key?.fromMe&&!isOperator(user,cfg)&&!(await isAdminAsync(meta,userJid,sock))&&s.antispam){const c=recordActivity(files.spam,jid,user,SPAM_WINDOW_MS);if(c>SPAM_MAX_MESSAGES){clearActivity(files.spam,jid,user);return moderate(sock,msg,cfg,`anti-spam : ${SPAM_MAX_MESSAGES} messages maximum en ${SPAM_WINDOW_MS} ms`);}}if(msg?.key?.fromMe||isOperator(user,cfg)||await isAdminAsync(meta,user,sock))return false;if(s.antilink&&extractLinks(text))return moderate(sock,msg,cfg,'lien interdit');if(s.antiimage&&type==='image')return moderate(sock,msg,cfg,'photo interdite');if(s.antivideo&&type==='video')return moderate(sock,msg,cfg,'vidéo interdite');if(s.antiaudio&&type==='audio')return moderate(sock,msg,cfg,'audio interdit');if(s.antisticker&&type==='sticker')return moderate(sock,msg,cfg,'sticker interdit');if(s.antitagall&&mentionCount(msg)>1)return moderate(sock,msg,cfg,'mention massive interdite');if(s.antitag&&mentionCount(msg)>0)return moderate(sock,msg,cfg,'tag interdit');if(s.antimention&&mentionCount(msg)>0)return moderate(sock,msg,cfg,'mention interdite');return false;}

async function viewOnceCommand(sock,msg,jid,args){
  const ctx = msg?.message?.extendedTextMessage?.contextInfo;
  const quotedMessage = ctx?.quotedMessage;
  if(!quotedMessage || !ctx?.stanzaId){
    return sock.sendMessage(jid,{text:`👁️ Réponds directement à une photo, vidéo, audio ou document en vue unique avec ${PREFIX}vv.`});
  }
  const q = { key: { remoteJid: jid, id: ctx.stanzaId, participant: ctx.participant || undefined }, message: quotedMessage };
  try {
    const m = unwrap(q);
    const type = m?.imageMessage ? 'image' : m?.videoMessage ? 'video' : m?.audioMessage ? 'audio' : m?.documentMessage ? 'document' : null;
    if(!type) return sock.sendMessage(jid,{text:'❌ Le message cité n’est pas un média compatible avec vv.'});
    const buffer = await sock.downloadMediaMessage(q, 'buffer', {}, { logger: sock.logger });
    if(!buffer) return sock.sendMessage(jid,{text:'❌ Impossible de récupérer ce média.'});
    if(type==='image') await sock.sendMessage(jid,{image:buffer,caption:m.imageMessage.caption||''});
    else if(type==='video') await sock.sendMessage(jid,{video:buffer,caption:m.videoMessage.caption||'',mimetype:m.videoMessage.mimetype||'video/mp4'});
    else if(type==='audio') await sock.sendMessage(jid,{audio:buffer,mimetype:m.audioMessage.mimetype||'audio/mpeg',ptt:!!m.audioMessage.ptt});
    else await sock.sendMessage(jid,{document:buffer,mimetype:m.documentMessage.mimetype||'application/octet-stream',fileName:m.documentMessage.fileName||'media'});
    return sock.sendMessage(jid,{text:'👁️✅ Vue unique retirée : le média a été renvoyé normalement.'});
  } catch(e) {
    return sock.sendMessage(jid,{text:`❌ vv n’a pas pu récupérer le média : ${e?.message||'erreur inconnue'}`});
  }
}

const quizThemes = {
  general: [
    {q:'Quelle est la capitale du Cameroun ?',a:['yaounde','yaoundé']},
    {q:'Combien font 7 × 8 ?',a:['56']},
    {q:'Quelle planète est surnommée la planète rouge ?',a:['mars']},
    {q:'Combien de côtés possède un triangle ?',a:['3','trois']},
    {q:'Quel est le plus grand océan ?',a:['pacifique','océan pacifique']}
  ],
  culture: [
    {q:'Quelle est la capitale de la France ?',a:['paris']},
    {q:'Combien y a-t-il de continents ?',a:['7','sept']},
    {q:'Quel est le symbole chimique de l’or ?',a:['au']},
    {q:'Quel est le plus grand mammifère ?',a:['baleine bleue','baleinebleue']},
    {q:'Dans quel pays se trouvent les pyramides de Gizeh ?',a:['egypte','égypte']}
  ],
  histoire: [
    {q:'En quelle année commence la Première Guerre mondiale ?',a:['1914']},
    {q:'Qui fut le premier empereur des Français ?',a:['napoleon','napoléon','napoleon bonaparte','napoléon bonaparte']},
    {q:'En quelle année le Cameroun devient-il indépendant ?',a:['1960']},
    {q:'Quel mur est tombé en 1989 ?',a:['mur de berlin','berlin']},
    {q:'Quelle civilisation a construit Machu Picchu ?',a:['inca','incas']}
  ],
  sciences: [
    {q:'Quelle est la formule chimique de l’eau ?',a:['h2o']},
    {q:'Combien de planètes composent le système solaire ?',a:['8','huit']},
    {q:'Quel organe pompe le sang ?',a:['coeur','cœur']},
    {q:'Quelle force nous attire vers le sol ?',a:['gravite','gravité']},
    {q:'Quel gaz les humains respirent-ils principalement pour vivre ?',a:['oxygene','oxygène','o2']}
  ],
  maths: [
    {q:'Combien font 12 × 12 ?',a:['144']},
    {q:'Combien font 100 ÷ 4 ?',a:['25']},
    {q:'Quelle est la racine carrée de 81 ?',a:['9','neuf']},
    {q:'Combien vaut 15 + 27 ?',a:['42']},
    {q:'Combien de degrés mesure un angle droit ?',a:['90','90°']}
  ],
  football: [
    {q:'Combien de joueurs une équipe de football aligne-t-elle sur le terrain ?',a:['11','onze']},
    {q:'Combien de minutes dure normalement un match ?',a:['90']},
    {q:'Quel carton signifie une expulsion ?',a:['rouge','carton rouge']},
    {q:'Comment appelle-t-on le joueur qui garde le but ?',a:['gardien','gardien de but']},
    {q:'Combien de buts vaut un penalty réussi ?',a:['1','un']}
  ],
  musique: [
    {q:'Combien de notes compte la gamme diatonique classique ?',a:['7','sept']},
    {q:'Quel instrument possède généralement 88 touches ?',a:['piano']},
    {q:'Comment appelle-t-on la vitesse d’un morceau ?',a:['tempo']},
    {q:'Quel symbole indique une pause en musique ?',a:['silence']},
    {q:'Combien de cordes possède généralement une guitare classique ?',a:['6','six']}
  ]
};
function quizThemeKey(theme){
  const t=normText(theme).replace(/[^a-z0-9]+/g,'');
  const aliases={culturegenerale:'culture',culture:'culture',sciences:'sciences',science:'sciences',histoire:'histoire',maths:'maths',mathematiques:'maths',football:'football',foot:'football',musique:'musique',general:'general',generale:'general'};
  return aliases[t]||'general';
}
function quizReadConfig(){
  const p=path.join(DATA,'quiz.json');
  if(!fs.existsSync(p)) fs.writeFileSync(p,JSON.stringify({points:1},null,2));
  try{return JSON.parse(fs.readFileSync(p,'utf8'))||{points:1};}catch{return {points:1};}
}
function quizWriteConfig(cfg){fs.writeFileSync(path.join(DATA,'quiz.json'),JSON.stringify(cfg,null,2));}
function quizParticipants(msg){return [...new Set(mentions(msg).map(x=>String(x).replace(/:\d+$/,'')).filter(x=>/@s\.whatsapp\.net$/.test(x)))];}
async function quizStart(sock,jid,args,msg){
  if(!isGroup(jid))return'🧠 Le quiz se lance uniquement dans un groupe.';
  const participants=quizParticipants(msg);
  if(!participants.length)return`Usage : ${PREFIX}quiz <thème> @membre @membre\nExemple : ${PREFIX}quiz football @membre1 @membre2`;
  const themeText=args.join(' ').replace(/@\S+/g,' ').replace(/\s+/g,' ').trim()||'general';
  const theme=quizThemeKey(themeText), bank=quizThemes[theme];
  const cfg=quizReadConfig(), games=read(files.games);
  games[jid]={type:'quiz',theme,participants,startedAt:Date.now(),score:Object.fromEntries(participants.map(p=>[p,0])),questionIndex:0,answered:[],questions:bank.map(x=>({q:x.q,a:x.a}))};
  write(files.games,games);
  const q=games[jid].questions[0];
  const tags=participants.map(p=>`@${p.split('@')[0]}`).join(' ');
  await sock.sendMessage(jid,{text:`🧠✨ QUIZ OVER\n📚 Thème : ${theme}\n💎 Points par bonne réponse : ${cfg.points}\n👥 Participants : ${tags}\n\n❓ QUESTION 1/${bank.length}\n${q.q}\n\n👉 Répondez avec un point devant la réponse.\nExemple : .${q.a[0]}`,mentions:participants});
  return null;
}
async function gameStart(sock,jid,type,args,msg){
  if(type==='quiz') return quizStart(sock,jid,args,msg);
  if(!isGroup(jid))return'🎮 Les jeux se lancent dans un groupe.';
  return`🎮 ${type.toUpperCase()} lancé !`;
}
async function gameAnswer(sock,msg){
  const jid=msg.key.remoteJid;if(!isGroup(jid))return false;
  const games=read(files.games),g=games[jid];if(!g||g.type!=='quiz')return false;
  const user=senderId(msg,sock);if(!g.participants.includes(user))return false;
  const raw=messageText(msg);if(!raw.startsWith('.'))return false;
  const answer=normText(raw.slice(1).trim());if(!answer)return false;
  if(g.answered.includes(user)){return true;}
  const q=g.questions[g.questionIndex];if(!q)return false;
  const ok=q.a.some(a=>answer===normText(a));
  const cfg=quizReadConfig();
  g.answered.push(user);
  if(ok){g.score[user]=(g.score[user]||0)+Number(cfg.points||1);await sock.sendMessage(jid,{text:`✅ @${user.split('@')[0]} Réponse correcte ! +${cfg.points||1} point(s).\n🏆 Score : ${g.score[user]}`,mentions:[user]});}
  else await sock.sendMessage(jid,{text:`❌ @${user.split('@')[0]} Réponse incorrecte.`,mentions:[user]});
  if(g.answered.length>=g.participants.length){
    g.questionIndex++;
    g.answered=[];
    if(g.questionIndex>=g.questions.length){
      const ranking=[...g.participants].sort((a,b)=>(g.score[b]||0)-(g.score[a]||0));
      const rows=ranking.map((p,i)=>`${i+1}. @${p.split('@')[0]} — ${g.score[p]||0} pt(s)`);
      await sock.sendMessage(jid,{text:`🏁 QUIZ TERMINÉ !\n📚 Thème : ${g.theme}\n\n🏆 CLASSEMENT\n${rows.join('\n')}`,mentions:ranking});
      delete games[jid];write(files.games,games);return true;
    }
    const nq=g.questions[g.questionIndex];
    await sock.sendMessage(jid,{text:`\n❓ QUESTION ${g.questionIndex+1}/${g.questions.length}\n${nq.q}\n\n👉 Tous les participants répondent avec un point devant la réponse.`,mentions:g.participants});
  }
  write(files.games,games);return true;
}

function groupOnly(jid){return isGroup(jid);}
async function requireAdmin(sock,jid,user){const meta=await metadata(sock,jid);return meta&&isAdmin(meta,user)?meta:null;}
async function doGroupAction(sock,msg,cfg,action,args){const jid=msg.key.remoteJid;if(!groupOnly(jid))return '❌ Cette commande doit être utilisée dans un groupe.';const meta=await metadata(sock,jid);const user=senderId(msg,sock);if(!meta||(!(await isAdminAsync(meta,user,sock))&&!isOperator(user,cfg)))return'🔒 Administrateurs uniquement.';if(!(await botIsAdmin(meta,sock))&&['kick','remove','mute','unmute','promote','demote','clean'].includes(action))return'❌ Le bot doit être administrateur.';if(action==='mute'){try{await sock.groupSettingUpdate(jid,'announcement');return'🔇 Groupe fermé : seuls les administrateurs peuvent envoyer des messages.';}catch(e){return`❌ Impossible de fermer le groupe : ${e?.message||'droits insuffisants'}`;}}if(action==='unmute'){try{await sock.groupSettingUpdate(jid,'not_announcement');return'🔊 Groupe ouvert : tous les membres peuvent envoyer des messages.';}catch(e){return`❌ Impossible d’ouvrir le groupe : ${e?.message||'droits insuffisants'}`;}}const target=targetJid(msg,sock,args);if(['kick','remove','promote','demote'].includes(action)&&!target)return`Usage: ${PREFIX}${action} @membre`;if(['kick','remove'].includes(action)){await sock.groupParticipantsUpdate(jid,[target],'remove');return`🚫 @${target.split('@')[0]} retiré.`;}if(action==='promote'){await sock.groupParticipantsUpdate(jid,[target],'promote');return`⬆️ @${target.split('@')[0]} promu administrateur.`;}if(action==='demote'){await sock.groupParticipantsUpdate(jid,[target],'demote');return`⬇️ @${target.split('@')[0]} rétrogradé.`;}if(action==='mute')return`🔇 Fonction mute enregistrée pour @${target.split('@')[0]}. WhatsApp ne fournit pas de mute individuel natif : utilise les permissions du groupe.`;if(action==='clean'){const n=Math.min(Math.max(Number(args[0])||1,1),50);return`🧹 Demande de nettoyage reçue (${n}). La suppression en masse dépend des droits et des messages réellement accessibles.`;}if(action==='tag'||action==='tagall'||action==='hidetag'){const ps=meta.participants||[];const mentionsList=ps.map(p=>p.id).filter(Boolean);const text=args.join(' ')||'📢';return sock.sendMessage(jid,{text,mentions:mentionsList});}if(action==='grouplink'){const code=await sock.groupInviteCode(jid);return`🔗 https://chat.whatsapp.com/${code}`;}if(action==='welcome'||action==='goodbye'){const s=read(files.settings);s[jid]=s[jid]||{};s[jid][action]=args[0]!=='off';write(files.settings,s);return`⚙️ ${action}: ${s[jid][action]?'activé':'désactivé'}`;}if(action==='poll'){const q=args.join(' ')||'Sondage';return sock.sendMessage(jid,{poll:{name:q,values:['Oui','Non'],selectableCount:1}});}return'⚙️ Commande groupe reconnue.';}

const aliasGroups={
 admin:['kick','remove','mute','unmute','demote','promote','tag','tagall','hidetag','grouplink','welcome','goodbye','poll','clean'],
 media:['play','son','video','playaudio','playvideo','sendimage','tosticker','sticker','tomp3','youtube','tiktok','facebook','instagram','pinterest','twitter','reddit','mediafire','apk','song','film','download'],
 tools:['translate','lyrics','fancy','wiki','define','currency','ip','qr','readqr','password','styletext','base64','shorten','reminder','gauth','getpp','setpp'],
 audio:['bass','deep','fast','slow','nightcore','reverse','robot','blown','earrape','echo'],
 reactions:['hug','kiss','slap','pat','punch','bite','cuddle','poke','wave','wink','dance','cry'],
 textmaker:['gold','naruto','pubg','frozen','deadpool','galaxy','neon','hacker','metallic','thunder'],
 search:['movie','wallpaper','img','npm'], anime:['waifu','megumin','konachan','hwaifu'], osint:['whois','dns','ssl','headers','sitestatus'],
 owner:['mode','alwaysonline','autostatus','antidelete','sudo','update','broadcast','clearsession','afk','antiedit','verrouillage','sync'],
 economy:['daily','balance','work','deposit','withdraw','give','baltop','rob','slots','gamble','shop','buy','inventory'],
 games:['rps','guess','hangman','8ball','coinflip','roll','fact','wyr','rate','ttt','wcg']
};
const externalNotice=new Set([...aliasGroups.media,aliasGroups.tools,...aliasGroups.audio,...aliasGroups.textmaker,...aliasGroups.search,...aliasGroups.anime,...aliasGroups.osint]);
function replyFor(cmd){if(cmd==='ping')return'🏓 Pong — Over actif.';if(cmd==='info')return`💀 Over v5.1.death\n🔐 Connexion : numéro configuré au démarrage\nPrefix: ${PREFIX}\n🛡️ Anti général: 3 warnings → retrait\n🚨 Anti-spam: ${SPAM_MAX_MESSAGES} messages / ${SPAM_WINDOW_MS} ms → sanction au ${SPAM_MAX_MESSAGES+1}e`;if(cmd==='help'||cmd==='menu')return menu();return`⚙️ ${cmd}: commande intégrée.`;}
async function safeTranslate(text){
  const q=String(text||'').trim();
  if(!q) return null;
  const url='https://api.mymemory.translated.net/get?q='+encodeURIComponent(q)+'&langpair=autodetect|en';
  const r=await fetch(url,{headers:{'Accept':'application/json'},signal:AbortSignal.timeout(12000)});
  if(!r.ok) throw new Error('Translation API HTTP '+r.status);
  const j=await r.json();
  return j?.responseData?.translatedText || null;
}
async function aiAnswer(prompt){
  const groq=process.env.GROQ_API_KEY;
  if(groq){
    const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${groq}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.GROQ_MODEL||'llama-3.1-8b-instant',messages:[{role:'user',content:prompt}],max_tokens:500}),signal:AbortSignal.timeout(20000)});
    if(!r.ok) throw new Error(`Groq HTTP ${r.status}`);
    const j=await r.json();
    return j?.choices?.[0]?.message?.content?.trim()||null;
  }
  const hf=process.env.HUGGINGFACE_API_KEY;
  if(hf){
    const r=await fetch('https://router.huggingface.co/v1/chat/completions',{method:'POST',headers:{Authorization:`Bearer ${hf}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.HUGGINGFACE_MODEL||'HuggingFaceH4/zephyr-7b-beta',messages:[{role:'user',content:prompt}],max_tokens:500}),signal:AbortSignal.timeout(20000)});
    if(!r.ok) throw new Error(`Hugging Face HTTP ${r.status}`);
    const j=await r.json();
    return j?.choices?.[0]?.message?.content?.trim()||null;
  }
  return null;
}

async function githubTools(query){
  const q=String(query||'').trim();
  if(!q) return null;
  const u='https://api.github.com/search/repositories?q='+encodeURIComponent(q)+'&sort=stars&order=desc&per_page=5';
  const r=await fetch(u,{headers:{'Accept':'application/vnd.github+json','User-Agent':'Over-5.1-death'},signal:AbortSignal.timeout(12000)});
  if(!r.ok) throw new Error('GitHub API HTTP '+r.status);
  const j=await r.json();
  return (j.items||[]).map(x=>`• ${x.full_name} ⭐${x.stargazers_count}\n  ${x.html_url}`).join('\n') || 'Aucun dépôt trouvé.';
}
function utilityCommand(sock,jid,cmd,args){if(['ai','gpt','ask'].includes(cmd)){return aiAnswer(args.join(' ')).then(x=>x?`🤖 ${x}`:'🤖 API IA non configurée. Ajoute GROQ_API_KEY ou HUGGINGFACE_API_KEY dans les variables de Silly Dev.').catch(e=>`❌ IA indisponible: ${e.message}`);}if(cmd==='password'){const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';let out='';for(let i=0;i<(Number(args[0])||12);i++)out+=chars[Math.floor(Math.random()*chars.length)];return`🔐 Mot de passe: ${out}`;}if(cmd==='base64'){const x=args.join(' ');return x?`🔤 Base64: ${Buffer.from(x).toString('base64')}`:'Usage: '+PREFIX+'base64 texte';}if(cmd==='styletext')return`✨ ${args.join(' ')}`;if(cmd==='fancy')return`✨ ${args.join(' ')}`;if(cmd==='roll'){const n=Math.max(2,Number(args[0])||6);return`🎲 ${1+Math.floor(Math.random()*n)}/${n}`;}if(cmd==='coinflip')return`🪙 ${Math.random()<.5?'Pile':'Face'}`;if(cmd==='8ball'){const a=['Oui.','Non.','Peut-être.','Certainement.','Demande plus tard.'];return`🎱 ${a[Math.floor(Math.random()*a.length)]}`;}if(cmd==='fact')return'💡 Les abeilles communiquent notamment par des danses pour indiquer des ressources.';if(cmd==='wyr')return'🤔 Pourquoi ? Parce que cette commande attend une question.';if(cmd==='rate'){const n=Math.floor(Math.random()*11);return`⭐ Note: ${n}/10`;}if(cmd==='rps'){const choices=['pierre','feuille','ciseaux'];const b=choices[Math.floor(Math.random()*3)];return`✊✋✌️ Bot: ${b}. Toi: ${args[0]||'?'}.`;}if(cmd==='translate')return safeTranslate(args.join(' ')).then(x=>x?`🌐 🇬🇧 Traduction: ${x}`:'🌐 Traduction introuvable.').catch(e=>`❌ Traduction indisponible: ${e.message}`);if(cmd==='termux_tools'||cmd==='tools')return githubTools(args.join(' ')).then(x=>x?`🛠️ Outils GitHub:\n${x}`:'🛠️ Aucun résultat.').catch(e=>`❌ GitHub indisponible: ${e.message}`);if(cmd==='lyrics')return'🎵 Lyrics : recherche externe non configurée dans cette version autonome.';if(cmd==='reminder')return'⏰ Rappel : commande reconnue. Ajoute un service de scheduler pour une exécution différée réelle.';return null;}

async function handle(sock,msg,cfg,logger,services={}){const jid=msg.key.remoteJid;const userJid=senderId(msg,sock);const userNumber=await senderNumber(sock,msg);const user=userNumber||norm(userJid);PREFIX = cfg.prefix || PREFIX; const text=messageText(msg),masterOwner=isOwner(user,cfg),pairingOwner=isPairing(user,cfg),domainMaster=isDomainMaster(user,cfg),operator=msg?.key?.fromMe||isOperator(user,cfg),owner=operator,primary=isPrimary(user,cfg);if(!text.startsWith(PREFIX)){await gameAnswer(sock,msg);return;}if(isLocked(user)&&!owner)return;const [raw,...args]=text.slice(PREFIX.length).trim().split(/\s+/);const cmd=(raw||'').toLowerCase();if(!cmd)return;const friendSensitive=new Set(['pair','domaine','friend','setprefix','mode','sync','verrouillage','alwaysonline','autostatus','antidelete','sudo','update','broadcast','clearsession','afk','antiedit','info']); const friendAllowed=!friendSensitive.has(cmd)&&allowed(user,cmd,cfg);if(cmd==='setprefix'){if(!operator)return sock.sendMessage(jid,{text:'🔒 Owner uniquement.'});const np=normalizePrefix(args.join(' '));if(!np)return sock.sendMessage(jid,{text:`Usage : ${PREFIX}setprefix <nouveau préfixe>\nExemple : ${PREFIX}setprefix &`});PREFIX=np;cfg.prefix=np;savePrefix(np);return sock.sendMessage(jid,{text:`✅ Préfixe changé avec succès.\nNouveau préfixe : ${np}\nUtilise ${np}menu pour voir les commandes.`});}const ownerOnly=['mode','alwaysonline','autostatus','antidelete','sudo','update','broadcast','clearsession','afk','antiedit','verrouillage','sync','friend','pair','domaine'];if(ownerOnly.includes(cmd)&&!owner)return sock.sendMessage(jid,{text:'🔒 Owner uniquement.'});const adminCommand=aliasGroups.admin.includes(cmd);const antiCommand=/^(anti|antispam|groupguard)/i.test(cmd);if(!publicMode()&&!primary&&!friendAllowed&&!owner)return sock.sendMessage(jid,{text:'🔒 Accès refusé. Utilise la commande friend avec le propriétaire pour être autorisé.'});if(publicMode()&&!primary&&!friendAllowed&&!owner&&(adminCommand||antiCommand||ownerOnly.includes(cmd)))return sock.sendMessage(jid,{text:'🔒 Cette commande est réservée au propriétaire/amis.'});
  if(cmd==='domaine'&&owner){const sub=(args.shift()||'status').toLowerCase();if(['on','off'].includes(sub)){const state=setDomainActive(sub==='on');return sock.sendMessage(jid,{text:`🌐 DOMAINE ${state?'ACTIVÉ':'DÉSACTIVÉ'}\n${state?'Le premier numéro du panneau contrôle maintenant les sous-sessions.':'Le contrôle inter-sessions est désactivé.'}`});}return sock.sendMessage(jid,{text:`🌐 DOMAINE : ${domainActive()?'🟢 ACTIF':'🔴 INACTIF'}\nLe numéro initial du panneau est le maître des sous-sessions quand le domaine est actif.`});}
  if(cmd==='friend'&&owner){const sub=(args.shift()||'').toLowerCase();const tagged=mentions(msg);let n=norm(args.shift());if(tagged.length)n=norm(tagged[0]);if(sub==='list'){const f=listFriends();const rows=Object.entries(f).map(([num,v])=>`• ${num} → ${v.permissions?.length?v.permissions.join(', '):'aucune commande'}`);return sock.sendMessage(jid,{text:'🤝 FRIENDS\n'+(rows.join('\n')||'Aucun ami autorisé.')});}if(sub==='remove'){if(!n)return sock.sendMessage(jid,{text:`Usage : ${PREFIX}friend remove @membre`});removeFriend(n);return sock.sendMessage(jid,{text:`🗑️ Accès retiré pour @${n}`,mentions:[`${n}@s.whatsapp.net`]});}if(!sub&&tagged.length){setFriend(n,['*']);return sock.sendMessage(jid,{text:`🤝 @${n} est maintenant Friend.\n✓ Commandes normales autorisées\n✕ Pairing et fonctions internes protégés.`,mentions:[`${n}@s.whatsapp.net`]});}if(sub==='add'){if(!n)return sock.sendMessage(jid,{text:`Usage : ${PREFIX}friend add @membre`});setFriend(n,['*']);return sock.sendMessage(jid,{text:`🤝 Ami ajouté : ${n}\n✓ Toutes les commandes normales sont autorisées.\n✕ Pairing, domaine et fonctions internes restent protégés.`});}if(['access','commands','permissions'].includes(sub)){if(!n)return sock.sendMessage(jid,{text:`Usage: ${PREFIX}friend access <numéro>`});return sock.sendMessage(jid,{text:`🔐 Accès de ${n} :\n${friendPermissions(n).length?friendPermissions(n).join(', '):'aucune commande'}`});}if(sub==='allow'){const perms=args;setFriend(n,perms.length?perms:FRIEND_DEFAULT_PERMISSIONS);return sock.sendMessage(jid,{text:`✅ Commandes autorisées pour ${n}: ${friendPermissions(n).join(', ')}`});}if(sub==='deny'){const current=friendPermissions(n);const denied=args.length?current.filter(x=>!args.includes(x)):[];setFriend(n,denied);return sock.sendMessage(jid,{text:`🚫 Accès mis à jour pour ${n}: ${denied.length?denied.join(', '):'aucune commande'}`});}return sock.sendMessage(jid,{text:`Usage :\n${PREFIX}friend @membre\n${PREFIX}friend add @membre\n${PREFIX}friend remove @membre\n${PREFIX}friend access <numéro>\n${PREFIX}friend allow <numéro> <commandes...>\n${PREFIX}friend deny <numéro> [commandes...]`});}
  if(cmd==='pair'&&owner){
    const sub=(args.shift()||'create').toLowerCase();
    if(sub==='list'||sub==='status'){const rows=services.subsessions?.list?.()||[];return sock.sendMessage(jid,{text:'🔗 SOUS-SESSIONS\n'+(rows.length?rows.map(x=>`• ${x.number} → ${x.status}`).join('\n'):'Aucune sous-session.')});}
    const n=norm(args.shift());
    if(sub==='remove'||sub==='stop'){if(!n)return sock.sendMessage(jid,{text:`Usage: ${PREFIX}pair remove <numéro>`});const ok=services.subsessions?.stop?.(n);if(ok)removePaired(n);return sock.sendMessage(jid,{text:ok?`🛑 Sous-session ${n} arrêtée.`:`❌ Sous-session ${n} introuvable.`});}
    if(sub==='create'||/^\d{8,15}$/.test(sub)){const number=sub==='create'?n:sub;if(!number)return sock.sendMessage(jid,{text:`Usage: ${PREFIX}pair create <numéro>`});if(!services.subsessions?.create)return sock.sendMessage(jid,{text:'❌ Gestionnaire de sous-sessions indisponible.'});try{addPaired(number);await services.subsessions.create(number,{onPairing:(num,code)=>sock.sendMessage(jid,{text:`🔗 Sous-session +${num}\n🔑 Code de pairing : ${code}\nWhatsApp → Appareils connectés → Connecter avec un numéro de téléphone.`}),onOpen:(num)=>sock.sendMessage(jid,{text:`✅ Sous-session +${num} connectée.`}),onRevoked:(num)=>sock.sendMessage(jid,{text:`⚠️ Sous-session +${num} révoquée par WhatsApp. Un nouveau pairing est nécessaire.`}),onError:(num,e)=>sock.sendMessage(jid,{text:`❌ Sous-session +${num}: ${e?.message||'erreur de connexion'}`}),attachHandlers:(subSock)=>{subSock.ev.on('messages.upsert',async ev=>{for(const m of (ev.messages||[])){try{if(m?.message) await handle(subSock,m,cfg,logger,services);}catch{}}});}});return sock.sendMessage(jid,{text:`🔗 Création de la sous-session +${number}. Le code sera envoyé ici dès qu'il est disponible.`});}catch(e){return sock.sendMessage(jid,{text:`❌ Pairing impossible : ${e.message}`});}}
    return sock.sendMessage(jid,{text:`Usage: ${PREFIX}pair create <numéro> | list | status | remove <numéro>`});
  }
  if(cmd==='autoreact'||cmd==='autoreaction'){
    if(!owner&&!primary&&!friendAllowed&&!publicMode())return sock.sendMessage(jid,{text:'🔒 Accès refusé.'});
    const sub=(args.shift()||'status').toLowerCase();
    if(sub==='on'||sub==='off'){const st=setReactionSettings(jid,{enabled:sub==='on'});return sock.sendMessage(jid,{text:`💫 Réaction automatique : ${st.enabled?'🟢 activée':'🔴 désactivée'}${st.enabled?' → '+st.emoji:''}`});}
    if(sub==='set'){const emoji=(args.join(' ')||DEFAULT_REACTION).slice(0,8);const st=setReactionSettings(jid,{emoji});return sock.sendMessage(jid,{text:`💫 Emoji automatique : ${st.emoji}`});}
    const st=reactionSettings(jid);return sock.sendMessage(jid,{text:`💫 Réaction automatique : ${st.enabled?'🟢 activée':'🔴 désactivée'}\nEmoji : ${st.emoji}\nUsage : ${PREFIX}autoreact on | off | set <emoji>`});
  }
  if(cmd==='vv'||cmd==='viewonce'){ if(!owner&&!allowed(user,'vv',cfg)) return sock.sendMessage(jid,{text:'🔒 Accès refusé.'}); return viewOnceCommand(sock,msg,jid,args); }
  if(cmd==='antit'&&(owner||friendAllowed)){
    const sub=(args.shift()||'status').toLowerCase();
    const keys=Object.keys(DEFAULT_ANTI);
    if(sub==='on'||sub==='off'){
      const enabled=sub==='on';
      const a=read(files.anti);
      a[jid]={...DEFAULT_ANTI,...(a[jid]||{})};
      for(const key of keys) a[jid][key]=enabled;
      write(files.anti,a);
      return sock.sendMessage(jid,{text:`🛡️ ANTI TOTAL : ${enabled?'🟢 ACTIVÉ — toutes les protections anti sont actives.':'🔴 DÉSACTIVÉ — toutes les protections anti sont coupées.'}\n\nInclus : anti-statut, anti-lien, anti-vidéo, anti-photo, anti-mention, anti-tag, anti-tagall, anti-spam, anti-sticker, anti-audio, anti-bot, anti-kickall, anti-promote, anti-demote, anti-ban, anti-viewonce et anti-call.`});
    }
    if(['status','statut','list'].includes(sub)){
      const st=antiSettings(jid);
      return sock.sendMessage(jid,{text:`🛡️ ANTI TOTAL : ${keys.every(k=>st[k])?'🟢 ON':keys.every(k=>!st[k])?'🔴 OFF':'🟡 PARTIEL'}\n\n${keys.map(k=>`${st[k]?'🟢':'🔴'} ${k}`).join('\n')}\n\nUtilise ${PREFIX}antit on | off`});
    }
    return sock.sendMessage(jid,{text:`Usage : ${PREFIX}antit on | off | status`});
  }
  if(cmd==='anticall'&&(owner||friendAllowed)){
    const sub=(args.shift()||'status').toLowerCase();
    if(sub==='on'||sub==='off'){
      setAnti(jid,'anticall',sub==='on');
      return sock.sendMessage(jid,{text:`📵 ANTI-CALL : ${sub==='on'?'🟢 activé — les appels de groupe reçus par le bot seront rejetés.':'🔴 désactivé.'}`});
    }
    return sock.sendMessage(jid,{text:`📵 ANTI-CALL : ${antiSettings(jid).anticall?'🟢 actif':'🔴 inactif'}\nUtilise ${PREFIX}anticall on | off`});
  }
  if(cmd==='anti'&&(owner||friendAllowed)){const sub=(args.shift()||'status').toLowerCase(),map={link:'antilink',links:'antilink',spam:'antispam',photo:'antiimage',photos:'antiimage',video:'antivideo',videos:'antivideo',mention:'antimention',mentions:'antimention',sticker:'antisticker',audio:'antiaudio',bot:'antibot',tag:'antitag',tagall:'antitagall',kickall:'antikickall',viewonce:'antiviewonce',demote:'antidemote',promote:'antipromote',ban:'antiban',group:'groupguard', statut:'antistatut', status:'antistatut', call:'anticall', calls:'anticall'};if(['list','status'].includes(sub)){const s=antiSettings(jid);return sock.sendMessage(jid,{text:'🛡️ Anti settings:\n'+Object.entries(s).map(([k,v])=>`${v?'🟢':'🔴'} ${k}`).join('\n')+`\n🚨 ${SPAM_MAX_MESSAGES} max / ${SPAM_WINDOW_MS} ms → sanction au ${SPAM_MAX_MESSAGES+1}e`});}const key=map[sub];if(!key)return sock.sendMessage(jid,{text:`Usage: ${PREFIX}anti status | ${PREFIX}anti spam on | ${PREFIX}anti link on`});const val=(args.shift()||'on').toLowerCase()!=='off';setAnti(jid,key,val);return sock.sendMessage(jid,{text:`🛡️ ${key}: ${val?'activé':'désactivé'}`});}
  if(cmd==='antispam'&&(owner||friendAllowed)){const sub=(args.shift()||'status').toLowerCase();if(sub==='on'||sub==='off'){setAnti(jid,'antispam',sub==='on');return sock.sendMessage(jid,{text:`🚨 Anti-spam ${sub==='on'?'activé':'désactivé'}`});}return sock.sendMessage(jid,{text:`🚨 Anti-spam: ${antiSettings(jid).antispam?'🟢 actif':'🔴 inactif'} — ${SPAM_MAX_MESSAGES} max / ${SPAM_WINDOW_MS} ms`});}
  const directAnti={
    'antipromote':'antipromote','anti-promote':'antipromote',
    'antidemote':'antidemote','anti-demote':'antidemote',
    'antilink':'antilink','anti-link':'antilink',
    'antispam':'antispam','anti-spam':'antispam',
    'antisticker':'antisticker','anti-sticker':'antisticker',
    'antiaudio':'antiaudio','anti-audio':'antiaudio',
    'antivideo':'antivideo','anti-video':'antivideo',
    'antiimage':'antiimage','anti-image':'antiimage','antiphoto':'antiimage','anti-photo':'antiimage',
    'antibot':'antibot','anti-bot':'antibot',
    'antimention':'antimention','anti-mention':'antimention',
    'antitag':'antitag','anti-tag':'antitag',
    'antitagall':'antitagall','anti-tagall':'antitagall',
    'antikickall':'antikickall','anti-kickall':'antikickall',
    'antistatut':'antistatut','anti-statut':'antistatut','antistatus':'antistatut',
    'antiviewonce':'antiviewonce','anti-viewonce':'antiviewonce',
    'antiban':'antiban','anti-ban':'antiban',
    'groupguard':'groupguard','anti-groupguard':'groupguard',
    'anticall':'anticall','anti-call':'anticall'
  };
  if(directAnti[cmd]&&(owner||friendAllowed||allowed(user,'anti',cfg))){
    const key=directAnti[cmd], sub=(args.shift()||'status').toLowerCase();
    if(sub==='on'||sub==='off'){setAnti(jid,key,sub==='on');return sock.sendMessage(jid,{text:`🛡️ ${key}: ${sub==='on'?'activé':'désactivé'}`});}
    return sock.sendMessage(jid,{text:`🛡️ ${key}: ${antiSettings(jid)[key]?'🟢 actif':'🔴 inactif'}\nUtilise ${PREFIX}${cmd} on|off`});
  }
  if(cmd==='quiz'){
    const sub=(args[0]||'').toLowerCase();
    if(sub==='points'){
      if(!owner)return sock.sendMessage(jid,{text:'🔒 Seul le propriétaire/numéro de pairing autorisé peut modifier les points.'});
      const n=Math.max(1,Math.min(100,Number(args[1]))||1);const qc=quizReadConfig();qc.points=n;quizWriteConfig(qc);
      return sock.sendMessage(jid,{text:`💎 Quiz : ${n} point(s) par bonne réponse.`});
    }
    if(sub==='status'){
      const qc=quizReadConfig();return sock.sendMessage(jid,{text:`🧠 QUIZ
💎 Points : ${qc.points}
📚 Thèmes : ${Object.keys(quizThemes).join(', ')}`});
    }
    await quizStart(sock,jid,args,msg);return true;
  }
  if(cmd==='game'){const gt=(args.shift()||'quiz').toLowerCase();if(gt==='quiz'){await quizStart(sock,jid,args,msg);return true;}return sock.sendMessage(jid,{text:await gameStart(sock,jid,gt,args,msg)});}
  if(aliasGroups.admin.includes(cmd))return sock.sendMessage(jid,{text:await doGroupAction(sock,msg,cfg,cmd,args)});
  if(['mode','alwaysonline','autostatus','antidelete','sudo','update','broadcast','clearsession','afk','antiedit','verrouillage','sync'].includes(cmd)){if(!owner)return sock.sendMessage(jid,{text:'🔒 Owner uniquement.'});if(cmd==='mode'){const v=(args[0]||'').toLowerCase();if(v==='public'||v==='publique'){setPublicMode(true);return sock.sendMessage(jid,{text:'🌐 Mode PUBLIC activé. Commandes générales ouvertes; anti, modération et propriétaire restent protégées.'});}if(v==='private'||v==='prive'||v==='privé'){setPublicMode(false);return sock.sendMessage(jid,{text:'🔐 Mode PRIVÉ activé. Seuls propriétaire, primaires, amis et sous-sessions autorisées utilisent le bot.'});}return sock.sendMessage(jid,{text:'⚙️ Mode actuel : '+(publicMode()?'PUBLIC':'PRIVÉ')+'\nUsage : '+PREFIX+'mode public | '+PREFIX+'mode private'});}if(cmd==='verrouillage'){const n=norm(args[0]);if(!n)return sock.sendMessage(jid,{text:'Usage : '+PREFIX+'verrouillage <numéro> [on|off]'});const val=(args[1]||'on').toLowerCase()!=='off';setLocked(n,val);return sock.sendMessage(jid,{text:val?'🔒 '+n+' est verrouillé silencieusement.':'🔓 '+n+' est déverrouillé.'});}if(cmd==='sync'){const state=setSyncActive(!syncActive());return sock.sendMessage(jid,{text:'🔄 SYNC '+(state?'ACTIVÉ':'DÉSACTIVÉ')+' : contrôle propriétaire des sous-sessions synchronisé. Aucun signalement massif automatique.'});}if(cmd==='clearsession')return sock.sendMessage(jid,{text:'🔒 Suppression automatique désactivée : aucune session ne sera effacée.'});return sock.sendMessage(jid,{text:'👑 '+cmd+' : option activée.'});}
  if(['son','video','film','download'].includes(cmd)){
    const url=args[0];if(!/^https?:\/\//i.test(url||''))return sock.sendMessage(jid,{text:`📥 Usage : ${PREFIX}${cmd} <URL directe>`});
    return sock.sendMessage(jid,{text:`📥 ${cmd} : URL reçue. Cette version accepte les URL directes publiques ; elle n'extrait pas les contenus protégés ou les vidéos de plateformes.`});
  }
  if(cmd==='listowner')return sock.sendMessage(jid,{text:`👑 Propriétaire : 237679433989\n👑 Sous-propriétaire : 237696789087`});
  if(cmd==='listpremium'){const friends=listFriends();const nums=Object.keys(friends);return sock.sendMessage(jid,{text:'💎 Amis préautorisés :\n'+(nums.length?nums.map(n=>'• '+n).join('\n'):'Aucun')});}
  if(cmd==='addowner'||cmd==='delowner')return sock.sendMessage(jid,{text:'🔒 Le propriétaire et le sous-propriétaire sont verrouillés dans cette version.'});
  if(cmd==='addprem'){if(!owner)return sock.sendMessage(jid,{text:'🔒 Owner uniquement.'});const n=norm(args[0]);if(!n)return sock.sendMessage(jid,{text:`Usage : ${PREFIX}addprem <numéro>`});setFriend(n,['*']);return sock.sendMessage(jid,{text:`💎 ${n} ajouté aux amis autorisés.`});}
  if(cmd==='delprem'){if(!owner)return sock.sendMessage(jid,{text:'🔒 Owner uniquement.'});const n=norm(args[0]);if(!n)return sock.sendMessage(jid,{text:`Usage : ${PREFIX}delprem <numéro>`});removeFriend(n);return sock.sendMessage(jid,{text:`🗑️ ${n} retiré des amis autorisés.`});}
  const util=await utilityCommand(sock,jid,cmd,args);if(util!==null)return sock.sendMessage(jid,{text:util});
  if(externalNotice.has(cmd)){if(!owner&&!primary&&!friendAllowed&&!publicMode())return sock.sendMessage(jid,{text:'🔒 Accès refusé.'});return sock.sendMessage(jid,{text:`🧩 ${cmd} est intégré au menu. Cette fonction nécessite un service/API externe configuré pour produire le résultat réel.`});}
  if(cmd==='ping'||cmd==='info'||cmd==='help'||cmd==='menu')return sock.sendMessage(jid,{text:replyFor(cmd)});
  if(!owner&&!primary&&!friendAllowed&&!publicMode())return sock.sendMessage(jid,{text:'🔒 Accès refusé.'});
  return sock.sendMessage(jid,{text:replyFor(cmd,args)});
}
module.exports={handle,antiMiddleware,handleParticipantUpdate,handleStatusMention,autoReactMiddleware};
