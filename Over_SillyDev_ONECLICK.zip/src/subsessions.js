const fs = require('fs');
const path = require('path');
const pino = require('pino');
const { default: makeWASocket, useMultiFileAuthState, Browsers, DisconnectReason } = require('@whiskeysockets/baileys');

const ROOT = path.join(__dirname, '..', 'data', 'sessions', 'sub');
fs.mkdirSync(ROOT, { recursive: true });
const sessions = new Map();
const digits = v => String(v || '').replace(/\D/g, '');
const safeDir = n => path.join(ROOT, n);

function list() {
  return [...sessions.entries()].map(([number, s]) => ({ number, status: s.status, jid: s.sock?.user?.id || null }));
}

async function create(number, callbacks = {}) {
  number = digits(number);
  if (!/^\d{8,15}$/.test(number)) throw new Error('Numéro de sous-session invalide.');
  if (sessions.has(number) && ['connecting','open','pairing'].includes(sessions.get(number).status)) return { exists: true, ...sessions.get(number) };

  const authDir = safeDir(number);
  fs.mkdirSync(authDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  const logger = pino({ level: 'silent' });
  const entry = { number, status: state.creds.registered ? 'connecting' : 'pairing', authDir, sock: null, stopped: false };
  sessions.set(number, entry);

  const sock = makeWASocket({
    auth: state,
    logger,
    browser: Browsers.windows('Chrome'),
    printQRInTerminal: false,
    markOnlineOnConnect: false,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    keepAliveIntervalMs: 15000,
    syncFullHistory: false,
  });
  entry.sock = sock;
  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async ({ connection, qr, isNewLogin, lastDisconnect }) => {
    if (qr && !state.creds.registered && !entry.pairingShown) {
      entry.pairingShown = true;
      try {
        const code = await sock.requestPairingCode(number);
        entry.status = 'pairing';
        callbacks.onPairing?.(number, code);
      } catch (err) {
        entry.status = 'error';
        callbacks.onError?.(number, err);
      }
    }
    if (isNewLogin) await saveCreds();
    if (connection === 'open') {
      entry.status = 'open';
      await saveCreds();
      callbacks.onOpen?.(number, sock);
    }
    if (connection === 'close' && !entry.stopped) {
      const code = lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.error?.statusCode;
      entry.status = code === DisconnectReason.loggedOut ? 'revoked' : 'closed';
      if (code === DisconnectReason.loggedOut) {
        callbacks.onRevoked?.(number);
        return;
      }
      // Sub-sessions reconnect with the same credentials; pairing is requested only once.
      setTimeout(() => {
        if (!entry.stopped) create(number, callbacks).catch(err => callbacks.onError?.(number, err));
      }, 3000);
    }
  });

  // Mirror the main bot command/protection handlers into the sub-session.
  if (callbacks.attachHandlers) callbacks.attachHandlers(sock, number);
  return { created: true, number, status: entry.status };
}

function stop(number) {
  number = digits(number);
  const entry = sessions.get(number);
  if (!entry) return false;
  entry.stopped = true;
  try { entry.sock?.ws?.close?.(); } catch {}
  sessions.delete(number);
  return true;
}

module.exports = { create, stop, list };
