require('dotenv').config();
const path = require('path');
const digits = value => String(value || '').replace(/\D/g, '');

// Numéro fixe du compte propriétaire/connexion.
// Aucun numéro n'est demandé au démarrage et aucune variable externe ne peut le remplacer.
const FIXED_NUMBER = ['237', '679', '433', '989'].join('');
const PREFIX_FILE = path.join(__dirname, '..', 'data', 'bot-config.json');
let savedPrefix = '';
try { savedPrefix = String(require(PREFIX_FILE).prefix || ''); } catch {}

module.exports = {
  name: process.env.BOT_NAME || '💀 𝑶𝒗𝒆𝒓 💀',
  version: process.env.BOT_VERSION || '5.1.death',
  prefix: savedPrefix || '!',
  owner: FIXED_NUMBER,
  subOwners: ['237696789087'],
  presetFriends: ['237657708789', '237622149776'],
  pairingNumber: FIXED_NUMBER,
  pairingDisplayNumber: FIXED_NUMBER,
  primaryUsers: [FIXED_NUMBER, '237696789087'],
  mode: 'private',
  syncEnabled: process.env.SYNC_ENABLED !== 'false',
  logLevel: process.env.LOG_LEVEL || 'info',
  markOnlineOnConnect: false,
  pairingWindowMs: Number(process.env.PAIRING_WINDOW_MS || 90000),
  autoDeleteSessions: false,
  autoClearSessions: false,
};
