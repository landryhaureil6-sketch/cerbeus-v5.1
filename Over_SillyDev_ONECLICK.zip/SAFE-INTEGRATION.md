# Over 5.1.death — intégration sûre du ZIP externe

Cette version incorpore les fonctions compatibles avec un bot WhatsApp normal :
- `!translate <texte>` : traduction vers l'anglais via MyMemory (API publique, sans clé).
- `!termux_tools <recherche>` / `!tools <recherche>` : recherche de dépôts GitHub via l'API publique.
- `!listowner`, `!listpremium`, `!addprem <numéro>`, `!delprem <numéro>` comme équivalents adaptés à WhatsApp.
- Chaque protection anti possède maintenant son propre `on/off`, notamment `!antisticker on/off`.

Les identifiants, tokens et clés trouvés dans le ZIP externe ne sont pas copiés dans Over. Les fonctions de mass-report, gel d'OTP, spam de jumelage et automatisations destinées à perturber des comptes/services ne sont pas intégrées.
