@echo off
cd /d %~dp0
if not exist node_modules (echo Lance install-windows.bat d'abord.&pause&exit /b 1)
node src/index.js
pause
