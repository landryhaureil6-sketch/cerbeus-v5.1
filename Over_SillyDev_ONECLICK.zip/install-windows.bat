@echo off
cd /d %~dp0
where node >nul 2>nul || (echo Installe Node.js LTS puis relance ce fichier.&pause&exit /b 1)
if not exist .env copy .env.example .env
npm install
pause
