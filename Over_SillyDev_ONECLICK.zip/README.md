# 💀༺ Over ༻💀 v5.1.death — connexion configurable

## 🔐 Identité propriétaire et numéro de connexion

- **Le propriétaire est fixé dans le code interne du bot** et n'est jamais demandé au démarrage.
- **Le numéro de connexion est le seul compte fixe configuré.**
- Le numéro propriétaire n'est pas affiché dans la console, le `.env`, le menu ou les messages du bot.
- Donner le ZIP à une autre personne ne lui donne pas un moyen de modifier le propriétaire via `.env` ou via le numéro de pairing.
- Si un autre numéro est choisi lors d'un nouveau lancement, l'ancienne session principale est **archivée**, pas supprimée.

### Lancement

Après `npm start` / `start-windows.bat`, le programme affiche :

```text
📱 Entre le numéro WhatsApp à connecter (indicatif pays, sans +) :
```

Exemple : `2376XXXXXXXX`

Le code de jumelage est ensuite généré pour **ce numéro uniquement**.

> Limite technique : aucune application distribuée à quelqu'un d'autre ne peut rendre une valeur réellement secrète si cette valeur doit être vérifiable localement. Ici, le propriétaire est surtout protégé contre les modifications normales de configuration : il n'est pas exposé comme variable `.env` et le numéro de connexion ne peut pas le remplacer.

# 💀༺ Over ༻💀 v5.1.death

Prefix par défaut : `'`

## Nouvelles fonctions
- Anti-link, anti-spam, anti-photo, anti-vidéo, anti-mention, anti-audio, anti-sticker.
- Système de 3 avertissements : au 3e, suppression automatique si le bot est administrateur.
- Les propriétaires et administrateurs sont exclus des sanctions automatiques.
- `anti ban` / `groupguard` = protections préventives (limitation d'actions risquées et surveillance). Cela ne peut pas garantir l'absence de suspension WhatsApp.
- `son` et `video` sont les commandes courtes réservées aux téléchargements médias (le moteur de téléchargement doit être fourni/configuré séparément).
- `game quiz (Alice) (Bob)` : quiz intégré.
- Session WhatsApp persistante dans `data/sessions/main`.

## Exemples
```text
'menu
'anti list
'anti link on
'anti photo on
'anti video on
'anti mention on
'anti spam on
'anti ban on
'warnings
'warnings reset 237XXXXXXXXX
'son <lien/recherche>
'video <lien/recherche>
'game quiz (Alice) (Bob)
```

## Important
Le bot ne peut pas garantir qu'un compte ou un groupe WhatsApp ne sera jamais suspendu. `antiban` est une protection préventive : elle évite les comportements automatisés à risque et permet de contrôler les fonctions du bot.

Les téléchargements audio/vidéo utilisent uniquement les fonctions disponibles dans cette version.


## Anti-spam v5.1.death
- Limite par défaut : **5 messages maximum en 500 ms** par utilisateur dans un groupe.
- Le **6e message** dans cette fenêtre déclenche une sanction via le système d'avertissements anti général.
- Propriétaire et administrateurs sont exemptés.
- Fenêtre configurable avec `ANTISPAM_WINDOW_MS` (par défaut `500`).
- Commandes : `'anti spam on`, `'anti spam off`, `'anti status`.


## Anti-spam
- Règle : 5 messages maximum dans une fenêtre de 500 ms.
- Le 6e message dans cette fenêtre déclenche la sanction anti-spam.
- Le propriétaire et les administrateurs sont exemptés.
- La sanction utilise le système d'avertissements général (3 avertissements entraînent la suppression si le bot est administrateur).
- La fenêtre de 500 ms est volontairement réaliste ; 0,5 microseconde n'est pas mesurable de façon fiable sur WhatsApp/Android.


### Réaction automatique
- `!autoreact on` : active la réaction automatique.
- `!autoreact off` : désactive la réaction automatique.
- `!autoreact set ❤️` : choisit l'emoji.
- `!autoreact status` : affiche l'état.

Les commandes de téléchargement direct (`!son`, `!video`, `!film`, `!download`) attendent une URL publique directe et ne contournent pas les protections des plateformes.

## Accès propriétaire et préfixe
- Le propriétaire principal est interne à la configuration du bot et n’est pas demandé au démarrage ni affiché dans le menu.
- Le numéro saisi au démarrage pour le pairing est également autorisé à utiliser les fonctions propriétaire.
- Le préfixe peut être changé avec `setprefix` et est conservé dans `data/bot-config.json`.

## 🧠 Quiz multijoueur
- `€quiz points 5` : définit le nombre de points par bonne réponse.
- `€quiz football @membre1 @membre2` : démarre un quiz sur le thème choisi avec les membres tagués.
- `€quiz status` : affiche la configuration du quiz.
- Les participants répondent avec un point devant la réponse, par exemple `.Paris`.
- Une réponse correcte ajoute les points configurés ; une réponse fausse affiche `Réponse incorrecte`.
