# Persistance Silly Dev / Pterodactyl

Le lanceur `sillydev-start.sh` garde le serveur actif si le processus Node se termine inopinément : il relance Node après 3 secondes.

## Important
- `data/sessions/main` n'est jamais supprimé par le programme.
- `data/sessions/pairing-recovery` n'est jamais supprimé par le programme.
- Les fichiers `data/*.json` ne sont pas nettoyés automatiquement.
- `npm start` lance le superviseur persistant.
- Le message `Server marked as offline...` est généré par Pterodactyl lorsque son processus principal s'arrête. Le programme ne peut pas supprimer ce texte de l'interface ; le superviseur réduit les arrêts dus à un crash Node en relançant automatiquement le processus.
- Une coupure forcée du conteneur (OOM, arrêt manuel, limite de plateforme) reste indépendante du programme.
