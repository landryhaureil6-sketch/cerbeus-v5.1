# Pairing WhatsApp

Le bot utilise `requestPairingCode()` et conserve les sessions sans suppression automatique.

Pour maximiser les notifications côté téléphone, `markOnlineOnConnect` est désactivé (`false`). La documentation Baileys indique que ce réglage permet de recevoir les notifications WhatsApp dans l’application.

Le code est demandé une seule fois lorsque le socket est en phase de connexion ou qu’un événement QR est reçu. Le programme ne régénère pas le code en boucle.

Si WhatsApp affiche « Impossible de connecter l’appareil », ce message peut aussi venir de WhatsApp lui-même (limite temporaire, appareil déjà lié, code expiré ou problème serveur). Le bot ne peut pas forcer WhatsApp à accepter un appareil refusé.
